# ProCam AI v2 — Smart HDR (Estilo iOS) & Interface Pro

- Motor Smart HDR natural com fusão guiada por luminância (preserva cores reais do sensor, curva fílmica S-Curve sem halos e sem CLAHE artificial).
- Interface inspirada no iOS Camera + Halide: tema OLED preto, acentos em amarelo iOS (#FFD60A), retículo animado de foco, miniatura ao vivo da galeria, controles PRO compactos e editor estilo Fotos do iOS.
