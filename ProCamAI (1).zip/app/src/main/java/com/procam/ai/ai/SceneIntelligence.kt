package com.procam.ai.ai

import android.graphics.RectF
import androidx.annotation.OptIn
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions

data class SceneTelemetry(
    val histogram: FloatArray = FloatArray(64),
    val averageLuma: Float = 128f,
    val isLowLight: Boolean = false,
    val isBacklit: Boolean = false,
    val detectedFaces: List<RectF> = emptyList(),
    val recommendedScene: String = "NATURAL"
)

class SceneIntelligenceAnalyzer(
    private val isFrontCamera: () -> Boolean,
    private val onTelemetry: (SceneTelemetry) -> Unit
) : ImageAnalysis.Analyzer {

    private var lastAnalyzedTimestamp = 0L

    private val faceDetector by lazy {
        val options = FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setMinFaceSize(0.12f)
            .build()
        FaceDetection.getClient(options)
    }

    @OptIn(ExperimentalGetImage::class)
    override fun analyze(imageProxy: ImageProxy) {
        val now = System.currentTimeMillis()
        if (now - lastAnalyzedTimestamp < 150L) {
            imageProxy.close()
            return
        }
        lastAnalyzedTimestamp = now

        val yPlane = imageProxy.planes[0].buffer
        val bins = IntArray(64)
        var lumaSum = 0L
        var darkPixels = 0
        var brightPixels = 0
        var sampleCount = 0

        val limit = yPlane.remaining()
        var i = 0
        while (i < limit) {
            val luma = yPlane.get(i).toInt() and 0xFF
            bins[luma shr 2]++
            lumaSum += luma
            if (luma < 42) darkPixels++
            if (luma > 220) brightPixels++
            sampleCount++
            i += 16
        }

        val maxBin = bins.maxOrNull()?.coerceAtLeast(1) ?: 1
        val normalized = FloatArray(64) { bins[it].toFloat() / maxBin }
        val avgLuma = if (sampleCount > 0) lumaSum.toFloat() / sampleCount else 128f
        val darkRatio = darkPixels.toFloat() / sampleCount.coerceAtLeast(1)
        val brightRatio = brightPixels.toFloat() / sampleCount.coerceAtLeast(1)
        val isLowLight = avgLuma < 56f
        val isBacklit = darkRatio > 0.22f && brightRatio > 0.14f

        val mediaImage = imageProxy.image
        if (mediaImage == null) {
            onTelemetry(
                SceneTelemetry(
                    histogram = normalized,
                    averageLuma = avgLuma,
                    isLowLight = isLowLight,
                    isBacklit = isBacklit,
                    recommendedScene = classifyScene(isLowLight, isBacklit, false)
                )
            )
            imageProxy.close()
            return
        }

        val rotation = imageProxy.imageInfo.rotationDegrees
        val inputImage = InputImage.fromMediaImage(mediaImage, rotation)
        val rotatedWidth = if (rotation == 90 || rotation == 270) imageProxy.height else imageProxy.width
        val rotatedHeight = if (rotation == 90 || rotation == 270) imageProxy.width else imageProxy.height

        faceDetector.process(inputImage)
            .addOnSuccessListener { faces ->
                val front = isFrontCamera()
                val normalizedBoxes = faces.map { face ->
                    val b = face.boundingBox
                    val left = (b.left.toFloat() / rotatedWidth).coerceIn(0f, 1f)
                    val top = (b.top.toFloat() / rotatedHeight).coerceIn(0f, 1f)
                    val right = (b.right.toFloat() / rotatedWidth).coerceIn(0f, 1f)
                    val bottom = (b.bottom.toFloat() / rotatedHeight).coerceIn(0f, 1f)
                    if (front) {
                        RectF(1f - right, top, 1f - left, bottom)
                    } else {
                        RectF(left, top, right, bottom)
                    }
                }

                onTelemetry(
                    SceneTelemetry(
                        histogram = normalized,
                        averageLuma = avgLuma,
                        isLowLight = isLowLight,
                        isBacklit = isBacklit,
                        detectedFaces = normalizedBoxes,
                        recommendedScene = classifyScene(isLowLight, isBacklit, normalizedBoxes.isNotEmpty())
                    )
                )
            }
            .addOnFailureListener {
                onTelemetry(
                    SceneTelemetry(
                        histogram = normalized,
                        averageLuma = avgLuma,
                        isLowLight = isLowLight,
                        isBacklit = isBacklit,
                        recommendedScene = classifyScene(isLowLight, isBacklit, false)
                    )
                )
            }
            .addOnCompleteListener {
                imageProxy.close()
            }
    }

    private fun classifyScene(isLowLight: Boolean, isBacklit: Boolean, hasFace: Boolean): String {
        return when {
            hasFace && isBacklit -> "SMART HDR"
            hasFace -> "RETRATO"
            isLowLight -> "NOITE"
            isBacklit -> "SMART HDR"
            else -> "NATURAL"
        }
    }

    fun close() {
        faceDetector.close()
    }
}
