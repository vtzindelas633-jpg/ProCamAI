package com.procam.ai.engine

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.hardware.camera2.CaptureRequest
import androidx.annotation.OptIn
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.Camera
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.concurrent.Executor
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.roundToInt

data class ProParameters(
    val isManualExposure: Boolean = false,
    val iso: Int? = null,
    val shutterSpeedNs: Long? = null,
    val focusDistance: Float? = null,
    val evIndex: Int = 0,
    val awbMode: Int = CaptureRequest.CONTROL_AWB_MODE_AUTO
)

data class HdrBracketCapture(
    val frames: List<Bitmap>,
    val baseIndex: Int
)

class ProCameraEngine(
    private val camera: Camera,
    private val imageCapture: ImageCapture,
    private val executor: Executor
) {

    @OptIn(ExperimentalCamera2Interop::class)
    fun applyProParameters(params: ProParameters) {
        val c2Control = Camera2CameraControl.from(camera.cameraControl)
        val builder = CaptureRequestOptions.Builder()
            .setCaptureRequestOption(CaptureRequest.CONTROL_AWB_MODE, params.awbMode)

        if (params.isManualExposure && params.iso != null && params.shutterSpeedNs != null) {
            builder
                .setCaptureRequestOption(
                    CaptureRequest.CONTROL_AE_MODE,
                    CaptureRequest.CONTROL_AE_MODE_OFF
                )
                .setCaptureRequestOption(CaptureRequest.SENSOR_SENSITIVITY, params.iso)
                .setCaptureRequestOption(CaptureRequest.SENSOR_EXPOSURE_TIME, params.shutterSpeedNs)
        } else {
            builder.setCaptureRequestOption(
                CaptureRequest.CONTROL_AE_MODE,
                CaptureRequest.CONTROL_AE_MODE_ON
            )
            val range = camera.cameraInfo.exposureState.exposureCompensationRange
            val clampedEv = params.evIndex.coerceIn(range.lower, range.upper)
            camera.cameraControl.setExposureCompensationIndex(clampedEv)
        }

        if (params.focusDistance != null) {
            builder
                .setCaptureRequestOption(
                    CaptureRequest.CONTROL_AF_MODE,
                    CaptureRequest.CONTROL_AF_MODE_OFF
                )
                .setCaptureRequestOption(CaptureRequest.LENS_FOCUS_DISTANCE, params.focusDistance)
        } else {
            builder.setCaptureRequestOption(
                CaptureRequest.CONTROL_AF_MODE,
                CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE
            )
        }

        c2Control.captureRequestOptions = builder.build()
    }

    /**
     * Bracketing inteligente estilo iOS:
     * Calcula os passos reais baseado no evStep do sensor:
     * -1.2 EV (salva céu/luzes), 0.0 EV (exposição base natural), +0.8 EV (detalhes em sombras).
     */
    suspend fun captureSmartHdrBracket(): HdrBracketCapture {
        val evState = camera.cameraInfo.exposureState
        val range = evState.exposureCompensationRange
        val originalEv = evState.exposureCompensationIndex
        val step = evState.exposureCompensationStep.toFloat().coerceAtLeast(0.1f)

        val underOffset = (-1.2f / step).roundToInt()
        val overOffset = (0.8f / step).roundToInt()

        val underEv = (originalEv + underOffset).coerceIn(range.lower, range.upper)
        val baseEv = originalEv.coerceIn(range.lower, range.upper)
        val overEv = (originalEv + overOffset).coerceIn(range.lower, range.upper)

        val targets = listOf(underEv, baseEv, overEv).distinct()
        val baseIndex = targets.indexOf(baseEv).coerceAtLeast(0)

        val frames = mutableListOf<Bitmap>()
        try {
            for (ev in targets) {
                camera.cameraControl.setExposureCompensationIndex(ev)
                delay(220L)
                frames.add(captureSingleBitmap())
            }
        } finally {
            camera.cameraControl.setExposureCompensationIndex(originalEv)
        }
        return HdrBracketCapture(frames = frames, baseIndex = baseIndex)
    }

    suspend fun captureNightBurst(frameCount: Int = 4): List<Bitmap> {
        val frames = mutableListOf<Bitmap>()
        repeat(frameCount) {
            frames.add(captureSingleBitmap())
            delay(65L)
        }
        return frames
    }

    suspend fun captureSingleBitmap(): Bitmap = suspendCancellableCoroutine { cont ->
        imageCapture.takePicture(executor, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                try {
                    val rotation = image.imageInfo.rotationDegrees
                    val buffer = image.planes[0].buffer
                    val bytes = ByteArray(buffer.remaining())
                    buffer.get(bytes)
                    image.close()

                    val rawBitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                        ?: throw IllegalStateException("Falha ao decodificar frame JPEG.")

                    val rotated = if (rotation != 0) {
                        val matrix = Matrix().apply { postRotate(rotation.toFloat()) }
                        Bitmap.createBitmap(
                            rawBitmap, 0, 0, rawBitmap.width, rawBitmap.height, matrix, true
                        ).also { rawBitmap.recycle() }
                    } else {
                        rawBitmap
                    }
                    cont.resume(rotated)
                } catch (e: Exception) {
                    image.close()
                    cont.resumeWithException(e)
                }
            }

            override fun onError(exception: ImageCaptureException) {
                cont.resumeWithException(exception)
            }
        })
    }
}
