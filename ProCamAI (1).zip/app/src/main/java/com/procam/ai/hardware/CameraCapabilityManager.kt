package com.procam.ai.hardware

import android.hardware.camera2.CameraCharacteristics
import android.util.Range
import androidx.annotation.OptIn
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.CameraInfo

data class HardwareCapabilities(
    val hardwareLevel: Int = CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_LEGACY,
    val hardwareLevelLabel: String = "LEGACY",
    val supportsManualSensor: Boolean = false,
    val supportsRaw: Boolean = false,
    val isoRange: Range<Int>? = null,
    val exposureTimeRangeNs: Range<Long>? = null,
    val minFocusDistance: Float = 0f,
    val evRange: Range<Int> = Range(0, 0),
    val evStep: Float = 0.5f,
    val hasFlashUnit: Boolean = false,
    val minZoom: Float = 1f,
    val maxZoom: Float = 1f
)

object CameraCapabilityManager {

    @OptIn(ExperimentalCamera2Interop::class)
    fun probe(cameraInfo: CameraInfo): HardwareCapabilities {
        val c2Info = Camera2CameraInfo.from(cameraInfo)

        val level = c2Info.getCameraCharacteristic(
            CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL
        ) ?: CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_LEGACY

        val levelLabel = when (level) {
            CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_3 -> "LEVEL_3"
            CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_FULL -> "FULL"
            CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_LIMITED -> "LIMITED"
            CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_EXTERNAL -> "EXTERNAL"
            else -> "LEGACY"
        }

        val capabilities = c2Info.getCameraCharacteristic(
            CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES
        ) ?: intArrayOf()

        val supportsManual = capabilities.contains(
            CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR
        )
        val supportsRaw = capabilities.contains(
            CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_RAW
        )

        val isoRange = c2Info.getCameraCharacteristic(
            CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE
        )
        val exposureRange = c2Info.getCameraCharacteristic(
            CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE
        )
        val minFocus = c2Info.getCameraCharacteristic(
            CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE
        ) ?: 0f

        val evState = cameraInfo.exposureState
        val zoomState = cameraInfo.zoomState.value

        return HardwareCapabilities(
            hardwareLevel = level,
            hardwareLevelLabel = levelLabel,
            supportsManualSensor = supportsManual && isoRange != null && exposureRange != null,
            supportsRaw = supportsRaw,
            isoRange = isoRange,
            exposureTimeRangeNs = exposureRange,
            minFocusDistance = minFocus,
            evRange = evState.exposureCompensationRange,
            evStep = evState.exposureCompensationStep.toFloat().coerceAtLeast(0.1f),
            hasFlashUnit = cameraInfo.hasFlashUnit(),
            minZoom = zoomState?.minZoomRatio ?: 1f,
            maxZoom = zoomState?.maxZoomRatio ?: 4f
        )
    }
}
