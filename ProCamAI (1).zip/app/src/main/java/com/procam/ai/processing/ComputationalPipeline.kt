package com.procam.ai.processing

import android.graphics.Bitmap
import android.graphics.RectF
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Point
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import org.opencv.photo.Photo
import kotlin.math.exp
import kotlin.math.pow
import kotlin.math.roundToInt

data class EditAdjustments(
    val exposure: Float = 0f,          // -1.0 .. +1.0
    val contrast: Float = 1f,          // 0.6 .. 1.5
    val saturation: Float = 1f,        // 0.0 .. 1.8
    val temperature: Float = 0f,       // -1.0 .. +1.0
    val shadowsHighlights: Float = 0f, // 0.0 .. 1.0
    val sharpness: Float = 0f,         // 0.0 .. 1.0
    val applyHdrBoost: Boolean = false
)

object ComputationalPipeline {

    @Volatile
    var isOpenCvReady: Boolean = false

    /**
     * Smart HDR estilo iOS:
     * 1. Alinha os frames (-EV, 0EV, +EV) para evitar fantasmas.
     * 2. Usa MergeMertens com pesos suaves para extrair alcance dinâmico sem halos.
     * 3. Fusão guiada por luminância em espaço LAB: preserva as cores reais do frame 0 EV
     *    e combina a luminância com o HDR para recuperar céu/realces e sombras naturalmente.
     * 4. Aplica curva fílmica S-Curve (pretos limpos, realces suaves, zero aspecto acinzentado).
     * 5. Aplica leve calor natural estilo Apple + micro-nitidez limpa.
     */
    fun processSmartHdr(
        frames: List<Bitmap>,
        baseIndex: Int,
        applyDenoise: Boolean
    ): Bitmap {
        require(frames.isNotEmpty()) { "Lista de frames vazia." }
        val safeBaseIdx = baseIndex.coerceIn(0, frames.lastIndex)
        if (!isOpenCvReady) return frames[safeBaseIdx]

        val mats = frames.map { bitmapToBgr(it) }
        val baseBgr = mats[safeBaseIdx].clone()

        val fusedBgr: Mat = if (mats.size > 1) {
            val alignMTB = Photo.createAlignMTB()
            alignMTB.process(mats, mats)

            // Pesos conservadores: evita cores artificiais e halos em bordas
            val fused32F = Mat()
            val mergeMertens = Photo.createMergeMertens(1.0f, 0.35f, 0.12f)
            mergeMertens.process(mats, fused32F)
            mats.forEach { it.release() }

            val mertens8U = Mat()
            fused32F.convertTo(mertens8U, CvType.CV_8UC3, 255.0)
            fused32F.release()

            // Combinação guiada por luminância no espaço LAB:
            // Mantém fidelidade de cor do frame 0 EV (82%) e puxa alcance dinâmico do HDR na luminância (52%)
            val labBase = Mat()
            val labMertens = Mat()
            Imgproc.cvtColor(baseBgr, labBase, Imgproc.COLOR_BGR2Lab)
            Imgproc.cvtColor(mertens8U, labMertens, Imgproc.COLOR_BGR2Lab)
            mertens8U.release()

            val baseCh = ArrayList<Mat>(3)
            val mertensCh = ArrayList<Mat>(3)
            Core.split(labBase, baseCh)
            Core.split(labMertens, mertensCh)

            val blendedL = Mat()
            val blendedA = Mat()
            val blendedB = Mat()
            Core.addWeighted(baseCh[0], 0.48, mertensCh[0], 0.52, 0.0, blendedL)
            Core.addWeighted(baseCh[1], 0.85, mertensCh[1], 0.15, 0.0, blendedA)
            Core.addWeighted(baseCh[2], 0.85, mertensCh[2], 0.15, 0.0, blendedB)

            val mergedLab = Mat()
            Core.merge(listOf(blendedL, blendedA, blendedB), mergedLab)

            val resultBgr = Mat()
            Imgproc.cvtColor(mergedLab, resultBgr, Imgproc.COLOR_Lab2BGR)

            baseCh.forEach { it.release() }
            mertensCh.forEach { it.release() }
            blendedL.release()
            blendedA.release()
            blendedB.release()
            mergedLab.release()
            labBase.release()
            labMertens.release()

            resultBgr
        } else {
            mats[0]
        }
        baseBgr.release()

        // Redução de ruído leve apenas em baixa luz
        val denoised = if (applyDenoise) {
            val d = Mat()
            Photo.fastNlMeansDenoisingColored(fusedBgr, d, 3.5f, 3.5f, 5, 11)
            fusedBgr.release()
            d
        } else {
            fusedBgr
        }

        // Acabamento estilo iOS: Curva fílmica natural + leve vibrância + micro-nitidez limpa
        val graded = applyIosPhotographicGrade(denoised, shadowLift = 0.14, warmth = 0.08, vibrance = 1.07)
        denoised.release()

        val sharpened = applyCleanSharpen(graded, amount = 0.18, sigma = 0.9)
        graded.release()

        return bgrToBitmapAndRelease(sharpened)
    }

    /**
     * Foto Automática Natural (estilo iOS): sem CLAHE agressivo, contraste limpo e cores fiéis.
     */
    fun processAutoSmart(
        bitmap: Bitmap,
        isLowLight: Boolean,
        isBacklit: Boolean
    ): Bitmap {
        if (!isOpenCvReady) return bitmap
        val bgr = bitmapToBgr(bitmap)

        val denoised = if (isLowLight) {
            val d = Mat()
            Photo.fastNlMeansDenoisingColored(bgr, d, 3.5f, 3.5f, 5, 11)
            bgr.release()
            d
        } else {
            bgr
        }

        val shadowLift = if (isBacklit) 0.22 else if (isLowLight) 0.16 else 0.08
        val graded = applyIosPhotographicGrade(denoised, shadowLift = shadowLift, warmth = 0.06, vibrance = 1.05)
        denoised.release()

        val sharpened = applyCleanSharpen(graded, amount = 0.15, sigma = 0.9)
        graded.release()

        return bgrToBitmapAndRelease(sharpened)
    }

    /**
     * Modo Noturno limpo: empilhamento temporal com preservação de pretos verdadeiros.
     */
    fun processNightStack(frames: List<Bitmap>): Bitmap {
        require(frames.isNotEmpty()) { "Lista de frames vazia." }
        if (!isOpenCvReady) return frames.first()

        val mats = frames.map { bitmapToBgr(it) }
        if (mats.size > 1) {
            val alignMTB = Photo.createAlignMTB()
            alignMTB.process(mats, mats)
        }

        val acc = Mat.zeros(mats[0].size(), CvType.CV_32FC3)
        val tmp = Mat()
        for (m in mats) {
            m.convertTo(tmp, CvType.CV_32FC3)
            Core.add(acc, tmp, acc)
            m.release()
        }
        tmp.release()

        val averaged = Mat()
        acc.convertTo(averaged, CvType.CV_8UC3, 1.0 / mats.size.toDouble())
        acc.release()

        val denoised = Mat()
        Photo.fastNlMeansDenoisingColored(averaged, denoised, 5.0f, 5.0f, 5, 13)
        averaged.release()

        // Recupera sombras mantendo o céu noturno escuro e natural
        val graded = applyIosPhotographicGrade(denoised, shadowLift = 0.26, warmth = 0.04, vibrance = 1.04)
        denoised.release()

        val sharpened = applyCleanSharpen(graded, amount = 0.20, sigma = 1.0)
        graded.release()

        return bgrToBitmapAndRelease(sharpened)
    }

    /**
     * Modo Retrato com bokeh suave e acabamento natural.
     */
    fun processPortraitBokeh(
        bitmap: Bitmap,
        faces: List<RectF>,
        blurRadius: Double = 33.0
    ): Bitmap {
        if (!isOpenCvReady) return bitmap
        val bgr = bitmapToBgr(bitmap)
        val rows = bgr.rows()
        val cols = bgr.cols()

        val blurred = Mat()
        val kSize = (blurRadius.toInt() or 1).coerceAtLeast(15)
        Imgproc.GaussianBlur(bgr, blurred, Size(kSize.toDouble(), kSize.toDouble()), 0.0)

        val mask = Mat.zeros(rows, cols, CvType.CV_32FC1)
        if (faces.isNotEmpty()) {
            for (face in faces) {
                val cx = ((face.left + face.right) / 2f) * cols
                val cy = ((face.top + face.bottom) / 2f) * rows
                val rx = (face.width() * cols * 0.95f).coerceAtLeast(cols * 0.18f)
                val ry = (face.height() * rows * 1.45f).coerceAtLeast(rows * 0.22f)
                Imgproc.ellipse(
                    mask,
                    Point(cx.toDouble(), (cy + ry * 0.25).coerceAtMost(rows.toDouble())),
                    Size(rx.toDouble(), ry.toDouble()),
                    0.0, 0.0, 360.0,
                    Scalar(1.0),
                    -1
                )
            }
        } else {
            Imgproc.ellipse(
                mask,
                Point(cols * 0.5, rows * 0.48),
                Size(cols * 0.28, rows * 0.36),
                0.0, 0.0, 360.0,
                Scalar(1.0),
                -1
            )
        }

        Imgproc.GaussianBlur(mask, mask, Size(95.0, 95.0), 0.0)

        val fgFloat = Mat()
        val bgFloat = Mat()
        bgr.convertTo(fgFloat, CvType.CV_32FC3)
        blurred.convertTo(bgFloat, CvType.CV_32FC3)

        val mask3 = Mat()
        Core.merge(listOf(mask, mask, mask), mask3)

        val invMask3 = Mat()
        Core.subtract(Mat.ones(mask3.size(), CvType.CV_32FC3), mask3, invMask3)

        val fgPart = Mat()
        val bgPart = Mat()
        Core.multiply(fgFloat, mask3, fgPart)
        Core.multiply(bgFloat, invMask3, bgPart)

        val combined32 = Mat()
        Core.add(fgPart, bgPart, combined32)
        val result8U = Mat()
        combined32.convertTo(result8U, CvType.CV_8UC3)

        bgr.release()
        blurred.release()
        mask.release()
        mask3.release()
        invMask3.release()
        fgFloat.release()
        bgFloat.release()
        fgPart.release()
        bgPart.release()
        combined32.release()

        val graded = applyIosPhotographicGrade(result8U, shadowLift = 0.10, warmth = 0.08, vibrance = 1.04)
        result8U.release()
        return bgrToBitmapAndRelease(graded)
    }

    /**
     * Editor não destrutivo estilo Fotos do iOS.
     */
    fun applyEditorAdjustments(source: Bitmap, adj: EditAdjustments): Bitmap {
        if (!isOpenCvReady) return source
        var current = bitmapToBgr(source)

        if (adj.exposure != 0f || adj.contrast != 1f) {
            val adjusted = Mat()
            val alpha = adj.contrast.toDouble()
            val beta = (adj.exposure * 58.0) + (1.0 - alpha) * 128.0
            current.convertTo(adjusted, CvType.CV_8UC3, alpha, beta)
            current.release()
            current = adjusted
        }

        if (adj.temperature != 0f) {
            val channels = ArrayList<Mat>(3)
            Core.split(current, channels)
            val delta = adj.temperature * 24.0
            Core.add(channels[2], Scalar(delta), channels[2])
            Core.add(channels[0], Scalar(-delta), channels[0])
            Core.merge(channels, current)
            channels.forEach { it.release() }
        }

        if (adj.saturation != 1f) {
            val hsv = Mat()
            Imgproc.cvtColor(current, hsv, Imgproc.COLOR_BGR2HSV)
            val channels = ArrayList<Mat>(3)
            Core.split(hsv, channels)
            channels[1].convertTo(channels[1], CvType.CV_8UC1, adj.saturation.toDouble(), 0.0)
            Core.merge(channels, hsv)
            val next = Mat()
            Imgproc.cvtColor(hsv, next, Imgproc.COLOR_HSV2BGR)
            channels.forEach { it.release() }
            hsv.release()
            current.release()
            current = next
        }

        if (adj.applyHdrBoost || adj.shadowsHighlights > 0.03f) {
            val lift = if (adj.applyHdrBoost) 0.24 else (adj.shadowsHighlights * 0.28).toDouble()
            val next = applyIosPhotographicGrade(current, shadowLift = lift, warmth = 0.04, vibrance = 1.05)
            current.release()
            current = next
        }

        if (adj.sharpness > 0.02f) {
            val next = applyCleanSharpen(current, amount = adj.sharpness * 0.55, sigma = 0.9)
            current.release()
            current = next
        }

        return bgrToBitmapAndRelease(current)
    }

    /**
     * Curva fílmica + recuperação suave de sombras em LUT (zero artefatos e zero halos)
     * + leve calor agradável + vibrância natural.
     */
    private fun applyIosPhotographicGrade(
        srcBgr: Mat,
        shadowLift: Double,
        warmth: Double,
        vibrance: Double
    ): Mat {
        // 1. Curva de tons na luminância (espaço LAB)
        val lab = Mat()
        Imgproc.cvtColor(srcBgr, lab, Imgproc.COLOR_BGR2Lab)
        val labCh = ArrayList<Mat>(3)
        Core.split(lab, labCh)

        val lutMat = buildFilmicToneLut(shadowLift = shadowLift, contrastStrength = 0.22)
        val mappedL = Mat()
        Core.LUT(labCh[0], lutMat, mappedL)
        lutMat.release()

        labCh[0].release()
        labCh[0] = mappedL
        Core.merge(labCh, lab)
        labCh.forEach { it.release() }

        val bgrToned = Mat()
        Imgproc.cvtColor(lab, bgrToned, Imgproc.COLOR_Lab2BGR)
        lab.release()

        // 2. Calor sutil estilo iOS (tons de pele mais naturais)
        if (warmth != 0.0) {
            val ch = ArrayList<Mat>(3)
            Core.split(bgrToned, ch)
            Core.add(ch[2], Scalar(warmth * 18.0), ch[2])  // Vermelho +
            Core.add(ch[0], Scalar(-warmth * 12.0), ch[0]) // Azul -
            Core.merge(ch, bgrToned)
            ch.forEach { it.release() }
        }

        // 3. Vibrância suave em HSV
        if (vibrance != 1.0) {
            val hsv = Mat()
            Imgproc.cvtColor(bgrToned, hsv, Imgproc.COLOR_BGR2HSV)
            val ch = ArrayList<Mat>(3)
            Core.split(hsv, ch)
            ch[1].convertTo(ch[1], CvType.CV_8UC1, vibrance, 0.0)
            Core.merge(ch, hsv)
            val out = Mat()
            Imgproc.cvtColor(hsv, out, Imgproc.COLOR_HSV2BGR)
            ch.forEach { it.release() }
            hsv.release()
            bgrToned.release()
            return out
        }

        return bgrToned
    }

    /**
     * Gera tabela LUT de 256 níveis combinando:
     * - Recuperação suave apenas nas sombras (sem lavar os pretos profundos)
     * - Curva S fílmica para contraste limpo e compressão suave de realces (highlight roll-off)
     */
    private fun buildFilmicToneLut(shadowLift: Double, contrastStrength: Double): Mat {
        val lut = Mat(1, 256, CvType.CV_8UC1)
        val data = ByteArray(256)
        for (i in 0..255) {
            val x = i / 255.0

            // Levantamento suave de sombras concentrado entre 0.08 e 0.45 (preserva preto real em 0.0)
            val shadowMask = x * (1.0 - x).pow(2.4) * 4.5
            var y = (x + shadowLift * shadowMask).coerceIn(0.0, 1.0)

            // Compressão suave de altas luzes (evita céu estourado)
            if (y > 0.78) {
                val over = (y - 0.78) / 0.22
                y = 0.78 + 0.22 * (1.0 - exp(-over * 1.45)) / (1.0 - exp(-1.45))
            }

            // Curva S sutil para profundidade estilo iOS
            val sCurve = y * y * (3.0 - 2.0 * y)
            val finalY = (y * (1.0 - contrastStrength) + sCurve * contrastStrength).coerceIn(0.0, 1.0)

            data[i] = (finalY * 255.0).roundToInt().coerceIn(0, 255).toByte()
        }
        lut.put(0, 0, data)
        return lut
    }

    private fun applyCleanSharpen(src: Mat, amount: Double, sigma: Double): Mat {
        val blurred = Mat()
        Imgproc.GaussianBlur(src, blurred, Size(0.0, 0.0), sigma)
        val dst = Mat()
        Core.addWeighted(src, 1.0 + amount, blurred, -amount, 0.0, dst)
        blurred.release()
        return dst
    }

    private fun bitmapToBgr(bitmap: Bitmap): Mat {
        val rgba = Mat()
        Utils.bitmapToMat(bitmap, rgba)
        val bgr = Mat()
        Imgproc.cvtColor(rgba, bgr, Imgproc.COLOR_RGBA2BGR)
        rgba.release()
        return bgr
    }

    private fun bgrToBitmapAndRelease(bgr: Mat): Bitmap {
        val rgba = Mat()
        Imgproc.cvtColor(bgr, rgba, Imgproc.COLOR_BGR2RGBA)
        bgr.release()
        val out = Bitmap.createBitmap(rgba.cols(), rgba.rows(), Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(rgba, out)
        rgba.release()
        return out
    }
}
