package com.procam.ai.ui

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.hardware.camera2.CaptureRequest
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.view.MotionEvent
import android.widget.Toast
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Cameraswitch
import androidx.compose.material.icons.rounded.FlashAuto
import androidx.compose.material.icons.rounded.FlashOff
import androidx.compose.material.icons.rounded.FlashOn
import androidx.compose.material.icons.rounded.GridOn
import androidx.compose.material.icons.rounded.HdrOn
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.ShowChart
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.procam.ai.ai.SceneIntelligenceAnalyzer
import com.procam.ai.ai.SceneTelemetry
import com.procam.ai.engine.ProCameraEngine
import com.procam.ai.engine.ProParameters
import com.procam.ai.hardware.CameraCapabilityManager
import com.procam.ai.hardware.HardwareCapabilities
import com.procam.ai.processing.ComputationalPipeline
import com.procam.ai.storage.MediaStoreSaver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.roundToInt

private val IosYellow = Color(0xFFFFD60A)
private val IosGlass = Color(0x881C1C1E)
private val IosSurface = Color(0xFF1C1C1E)
private val IosRed = Color(0xFFFF3B30)

enum class CameraMode(val label: String) {
    VIDEO("VÍDEO"),
    AUTO("FOTO"),
    HDR("SMART HDR"),
    PORTRAIT("RETRATO"),
    NIGHT("NOITE"),
    PRO("PRO")
}

private enum class ProTool(val label: String) {
    EV("EV"),
    ISO("ISO"),
    SHUTTER("VEL"),
    WB("WB")
}

@Composable
fun CameraScreen(
    onOpenGallery: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val haptic = LocalHapticFeedback.current
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()

    val cameraExecutor = remember { Executors.newSingleThreadExecutor() }
    val analysisExecutor = remember { Executors.newSingleThreadExecutor() }

    var lensFacing by remember { mutableIntStateOf(CameraSelector.LENS_FACING_BACK) }
    var selectedMode by remember { mutableStateOf(CameraMode.AUTO) }
    var flashMode by remember { mutableIntStateOf(ImageCapture.FLASH_MODE_AUTO) }
    var aiEnabled by remember { mutableStateOf(true) }
    var showGrid by remember { mutableStateOf(true) }
    var showHistogram by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var saveAsPng by remember { mutableStateOf(false) }
    var jpegQuality by remember { mutableIntStateOf(96) }

    var capabilities by remember { mutableStateOf(HardwareCapabilities()) }
    var telemetry by remember { mutableStateOf(SceneTelemetry()) }
    var isProcessing by remember { mutableStateOf(false) }
    var statusBanner by remember { mutableStateOf<String?>(null) }
    var shutterFlash by remember { mutableStateOf(false) }

    // Miniatura recente da galeria
    var lastThumb by remember { mutableStateOf<Bitmap?>(null) }

    // Retículo de toque para focar
    var focusTapOffset by remember { mutableStateOf<Offset?>(null) }

    // Controles PRO compactos
    var proParams by remember { mutableStateOf(ProParameters()) }
    var activeProTool by remember { mutableStateOf(ProTool.EV) }
    var zoomRatio by remember { mutableFloatStateOf(1f) }

    // Vídeo
    var activeRecording by remember { mutableStateOf<Recording?>(null) }
    var isRecording by remember { mutableStateOf(false) }

    var cameraRef by remember { mutableStateOf<Camera?>(null) }
    var imageCaptureRef by remember { mutableStateOf<ImageCapture?>(null) }
    var videoCaptureRef by remember { mutableStateOf<VideoCapture<Recorder>?>(null) }
    var proEngineRef by remember { mutableStateOf<ProCameraEngine?>(null) }

    val previewView = remember {
        PreviewView(context).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
    }

    val analyzer = remember {
        SceneIntelligenceAnalyzer(
            isFrontCamera = { lensFacing == CameraSelector.LENS_FACING_FRONT },
            onTelemetry = { telemetry = it }
        )
    }

    // Carrega última miniatura da galeria ao abrir
    LaunchedEffect(Unit) {
        lastThumb = withContext(Dispatchers.IO) {
            val latest = MediaStoreSaver.loadRecentPhotos(context, 1).firstOrNull()
            latest?.let { MediaStoreSaver.decodeBitmapFromUri(context, it.uri, 160) }
        }
    }

    // Esconde o retículo de foco após 1.4s
    LaunchedEffect(focusTapOffset) {
        if (focusTapOffset != null) {
            delay(1400L)
            focusTapOffset = null
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            activeRecording?.stop()
            analyzer.close()
            cameraExecutor.shutdown()
            analysisExecutor.shutdown()
        }
    }

    LaunchedEffect(lensFacing, selectedMode == CameraMode.VIDEO) {
        val providerFuture = ProcessCameraProvider.getInstance(context)
        providerFuture.addListener({
            try {
                val cameraProvider = providerFuture.get()
                cameraProvider.unbindAll()

                val selector = CameraSelector.Builder()
                    .requireLensFacing(lensFacing)
                    .build()

                val preview = Preview.Builder().build().also {
                    it.surfaceProvider = previewView.surfaceProvider
                }

                val imageCapture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                    .setFlashMode(flashMode)
                    .build()

                val imageAnalysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                    .also { it.setAnalyzer(analysisExecutor, analyzer) }

                val camera = if (selectedMode == CameraMode.VIDEO) {
                    val recorder = Recorder.Builder()
                        .setQualitySelector(QualitySelector.from(Quality.HIGHEST))
                        .build()
                    val videoCapture = VideoCapture.withOutput(recorder)
                    videoCaptureRef = videoCapture
                    cameraProvider.bindToLifecycle(
                        lifecycleOwner, selector, preview, videoCapture
                    )
                } else {
                    videoCaptureRef = null
                    cameraProvider.bindToLifecycle(
                        lifecycleOwner, selector, preview, imageCapture, imageAnalysis
                    )
                }

                cameraRef = camera
                imageCaptureRef = imageCapture
                proEngineRef = ProCameraEngine(camera, imageCapture, cameraExecutor)
                capabilities = CameraCapabilityManager.probe(camera.cameraInfo)
                zoomRatio = 1f
            } catch (e: Exception) {
                Toast.makeText(context, "Erro ao iniciar câmera: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(context))
    }

    LaunchedEffect(flashMode) {
        imageCaptureRef?.flashMode = flashMode
    }

    LaunchedEffect(proParams, selectedMode) {
        if (selectedMode == CameraMode.PRO) {
            proEngineRef?.applyProParameters(proParams)
        } else {
            proEngineRef?.applyProParameters(ProParameters())
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        // 1. Barra Superior Minimalista estilo iOS
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TopCircleIcon(
                active = flashMode == ImageCapture.FLASH_MODE_ON,
                onClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    flashMode = when (flashMode) {
                        ImageCapture.FLASH_MODE_AUTO -> ImageCapture.FLASH_MODE_ON
                        ImageCapture.FLASH_MODE_ON -> ImageCapture.FLASH_MODE_OFF
                        else -> ImageCapture.FLASH_MODE_AUTO
                    }
                }
            ) {
                val icon = when (flashMode) {
                    ImageCapture.FLASH_MODE_ON -> Icons.Rounded.FlashOn
                    ImageCapture.FLASH_MODE_OFF -> Icons.Rounded.FlashOff
                    else -> Icons.Rounded.FlashAuto
                }
                Icon(
                    icon,
                    contentDescription = "Flash",
                    tint = if (flashMode == ImageCapture.FLASH_MODE_ON) IosYellow else Color.White,
                    modifier = Modifier.size(19.dp)
                )
            }

            // Pill central de status (IA + Smart HDR)
            Row(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(IosGlass)
                    .clickable { aiEnabled = !aiEnabled }
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    Icons.Rounded.AutoAwesome,
                    contentDescription = "IA",
                    tint = if (aiEnabled) IosYellow else Color.Gray,
                    modifier = Modifier.size(14.dp)
                )
                Text(
                    text = if (aiEnabled) telemetry.recommendedScene else "IA OFF",
                    color = if (aiEnabled) Color.White else Color.Gray,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 0.6.sp
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TopCircleIcon(
                    active = showGrid,
                    onClick = { showGrid = !showGrid }
                ) {
                    Icon(
                        Icons.Rounded.GridOn,
                        contentDescription = "Grade",
                        tint = if (showGrid) IosYellow else Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }

                TopCircleIcon(
                    active = showHistogram,
                    onClick = { showHistogram = !showHistogram }
                ) {
                    Icon(
                        Icons.Rounded.ShowChart,
                        contentDescription = "Histograma",
                        tint = if (showHistogram) IosYellow else Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }

                TopCircleIcon(
                    active = showSettings,
                    onClick = { showSettings = !showSettings }
                ) {
                    Icon(
                        Icons.Rounded.Settings,
                        contentDescription = "Ajustes",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        // 2. Viewfinder com bordas arredondadas estilo iOS
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(horizontal = 6.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0xFF0A0A0C))
        ) {
            AndroidView(
                factory = {
                    previewView.setOnTouchListener { view, event ->
                        if (event.action == MotionEvent.ACTION_UP) {
                            focusTapOffset = Offset(event.x, event.y)
                            val factory = previewView.meteringPointFactory
                            val point = factory.createPoint(event.x, event.y)
                            val action = FocusMeteringAction.Builder(point).build()
                            cameraRef?.cameraControl?.startFocusAndMetering(action)
                            view.performClick()
                        }
                        true
                    }
                    previewView
                },
                modifier = Modifier.fillMaxSize()
            )

            // Grade Regra dos Terços sutil
            if (showGrid) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val stroke = 1.dp.toPx()
                    val gridColor = Color(0x33FFFFFF)
                    drawLine(gridColor, Offset(size.width / 3f, 0f), Offset(size.width / 3f, size.height), stroke)
                    drawLine(gridColor, Offset(size.width * 2f / 3f, 0f), Offset(size.width * 2f / 3f, size.height), stroke)
                    drawLine(gridColor, Offset(0f, size.height / 3f), Offset(size.width, size.height / 3f), stroke)
                    drawLine(gridColor, Offset(0f, size.height * 2f / 3f), Offset(size.width, size.height * 2f / 3f), stroke)
                }
            }

            // Detecção de rostos discreta estilo iOS
            if (aiEnabled && telemetry.detectedFaces.isNotEmpty() && selectedMode != CameraMode.VIDEO) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    for (box in telemetry.detectedFaces) {
                        drawRoundRect(
                            color = IosYellow.copy(alpha = 0.85f),
                            topLeft = Offset(box.left * size.width, box.top * size.height),
                            size = Size(box.width() * size.width, box.height() * size.height),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f, 10f),
                            style = Stroke(width = 2.5f)
                        )
                    }
                }
            }

            // Retículo de toque para focar estilo iOS
            focusTapOffset?.let { pos ->
                val reticleSizePx = with(density) { 68.dp.toPx() }
                Box(
                    modifier = Modifier
                        .offset {
                            IntOffset(
                                (pos.x - reticleSizePx / 2f).roundToInt(),
                                (pos.y - reticleSizePx / 2f).roundToInt()
                            )
                        }
                        .size(68.dp)
                        .border(1.5.dp, IosYellow, RoundedCornerShape(4.dp))
                )
            }

            // Histograma flutuante discreto no canto superior direito do viewfinder
            if (showHistogram && selectedMode != CameraMode.VIDEO) {
                LiveHistogramView(
                    bins = telemetry.histogram,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(12.dp)
                        .width(108.dp)
                        .height(36.dp)
                )
            }

            // Badge de gravação de vídeo
            if (isRecording) {
                Row(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 12.dp)
                        .clip(CircleShape)
                        .background(IosRed)
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("● GRAVANDO", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Piscada sutil do obturador ao fotografar
            val flashAlpha by animateFloatAsState(
                targetValue = if (shutterFlash) 0.55f else 0f,
                animationSpec = tween(110),
                label = "shutterFlash"
            )
            if (flashAlpha > 0.01f) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = flashAlpha))
                )
            }

            // Pill de Zoom estilo iOS na base do viewfinder
            if (capabilities.maxZoom > 1.1f) {
                Row(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 14.dp)
                        .clip(CircleShape)
                        .background(Color(0x99000000))
                        .padding(horizontal = 6.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val steps = listOf(1f, 2f, 4f).filter { it <= capabilities.maxZoom }
                    for (z in steps) {
                        val active = abs(zoomRatio - z) < 0.2f
                        Box(
                            modifier = Modifier
                                .size(if (active) 34.dp else 28.dp)
                                .clip(CircleShape)
                                .background(if (active) Color(0xCC2C2C2E) else Color.Transparent)
                                .border(
                                    width = if (active) 1.dp else 0.dp,
                                    color = if (active) IosYellow.copy(alpha = 0.7f) else Color.Transparent,
                                    shape = CircleShape
                                )
                                .clickable {
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    zoomRatio = z
                                    cameraRef?.cameraControl?.setZoomRatio(z)
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (active) "${z.toInt()}x" else "${z.toInt()}",
                                color = if (active) IosYellow else Color.White,
                                fontSize = if (active) 11.sp else 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Indicador elegante de processamento
            ProcessingPillOverlay(
                visible = isProcessing || statusBanner != null,
                isProcessing = isProcessing,
                statusBanner = statusBanner,
                modifier = Modifier.align(Alignment.Center)
            )

            // Painel de Configurações Avançadas
            if (showSettings) {
                SettingsOverlay(
                    capabilities = capabilities,
                    saveAsPng = saveAsPng,
                    jpegQuality = jpegQuality,
                    onTogglePng = { saveAsPng = it },
                    onQualityChange = { jpegQuality = it },
                    onClose = { showSettings = false }
                )
            }
        }

        // 3. Dock Inferior estilo iOS (Controles PRO compactos + Modos + Obturador)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(listOf(Color.Black, Color(0xFF0A0A0C)))
                )
                .padding(top = 10.dp, bottom = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Painel PRO compacto (um controle ativo por vez para não poluir a tela)
            if (selectedMode == CameraMode.PRO) {
                CompactProBar(
                    capabilities = capabilities,
                    params = proParams,
                    activeTool = activeProTool,
                    onSelectTool = { activeProTool = it },
                    onParamsChange = { proParams = it }
                )
            }

            // Carrossel de Modos estilo iOS
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(20.dp, Alignment.CenterHorizontally)
            ) {
                CameraMode.entries.forEach { mode ->
                    val selected = mode == selectedMode
                    Text(
                        text = mode.label,
                        color = if (selected) IosYellow else Color(0xFF8E8E93),
                        fontSize = 12.sp,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                        letterSpacing = 0.8.sp,
                        modifier = Modifier
                            .clickable {
                                if (!isRecording) {
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    selectedMode = mode
                                }
                            }
                            .padding(vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Linha principal: Miniatura Galeria | Botão de Disparo iOS | Trocar Lente
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 36.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Miniatura real da última foto (estilo iOS)
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(IosSurface)
                        .border(1.5.dp, Color(0x44FFFFFF), RoundedCornerShape(10.dp))
                        .clickable { onOpenGallery() },
                    contentAlignment = Alignment.Center
                ) {
                    if (lastThumb != null) {
                        Image(
                            bitmap = lastThumb!!.asImageBitmap(),
                            contentDescription = "Galeria",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Icon(
                            Icons.Rounded.PhotoLibrary,
                            contentDescription = "Galeria",
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }

                // Obturador clássico iOS
                val innerSize by animateDpAsState(
                    targetValue = when {
                        selectedMode == CameraMode.VIDEO && isRecording -> 30.dp
                        isProcessing -> 52.dp
                        else -> 60.dp
                    },
                    label = "shutterSize"
                )
                val innerCorner by animateDpAsState(
                    targetValue = if (selectedMode == CameraMode.VIDEO && isRecording) 8.dp else 30.dp,
                    label = "shutterCorner"
                )

                Box(
                    modifier = Modifier
                        .size(74.dp)
                        .clip(CircleShape)
                        .border(3.5.dp, Color.White, CircleShape)
                        .clickable(enabled = !isProcessing) {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            if (selectedMode == CameraMode.VIDEO) {
                                toggleVideoRecording(
                                    context = context,
                                    videoCapture = videoCaptureRef,
                                    activeRecording = activeRecording,
                                    onRecordingChanged = { rec, recording ->
                                        activeRecording = rec
                                        isRecording = recording
                                    }
                                )
                            } else {
                                val engine = proEngineRef ?: return@clickable
                                scope.launch {
                                    isProcessing = true
                                    shutterFlash = true
                                    delay(90L)
                                    shutterFlash = false
                                    try {
                                        val format = if (saveAsPng) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG
                                        val finalBitmap = when (selectedMode) {
                                            CameraMode.HDR -> {
                                                statusBanner = "Smart HDR..."
                                                val bracket = engine.captureSmartHdrBracket()
                                                withContext(Dispatchers.Default) {
                                                    ComputationalPipeline.processSmartHdr(
                                                        frames = bracket.frames,
                                                        baseIndex = bracket.baseIndex,
                                                        applyDenoise = telemetry.isLowLight
                                                    )
                                                }
                                            }
                                            CameraMode.NIGHT -> {
                                                statusBanner = "Modo Noturno (firme)..."
                                                val stack = engine.captureNightBurst(4)
                                                withContext(Dispatchers.Default) {
                                                    ComputationalPipeline.processNightStack(stack)
                                                }
                                            }
                                            CameraMode.PORTRAIT -> {
                                                statusBanner = "Retrato..."
                                                val bmp = engine.captureSingleBitmap()
                                                withContext(Dispatchers.Default) {
                                                    ComputationalPipeline.processPortraitBokeh(
                                                        bitmap = bmp,
                                                        faces = telemetry.detectedFaces
                                                    )
                                                }
                                            }
                                            CameraMode.PRO -> {
                                                engine.captureSingleBitmap()
                                            }
                                            else -> {
                                                if (aiEnabled && telemetry.isBacklit) {
                                                    statusBanner = "Smart HDR Automático..."
                                                    val bracket = engine.captureSmartHdrBracket()
                                                    withContext(Dispatchers.Default) {
                                                        ComputationalPipeline.processSmartHdr(
                                                            frames = bracket.frames,
                                                            baseIndex = bracket.baseIndex,
                                                            applyDenoise = false
                                                        )
                                                    }
                                                } else {
                                                    val bmp = engine.captureSingleBitmap()
                                                    if (aiEnabled) {
                                                        withContext(Dispatchers.Default) {
                                                            ComputationalPipeline.processAutoSmart(
                                                                bmp,
                                                                telemetry.isLowLight,
                                                                telemetry.isBacklit
                                                            )
                                                        }
                                                    } else bmp
                                                }
                                            }
                                        }

                                        val savedUri = withContext(Dispatchers.IO) {
                                            MediaStoreSaver.saveBitmap(
                                                context = context,
                                                bitmap = finalBitmap,
                                                prefix = "PROCAM_${selectedMode.name}",
                                                format = format,
                                                quality = jpegQuality
                                            )
                                        }
                                        if (savedUri != null) {
                                            lastThumb = withContext(Dispatchers.IO) {
                                                MediaStoreSaver.decodeBitmapFromUri(context, savedUri, 160)
                                            }
                                        } else {
                                            Toast.makeText(context, "Erro ao salvar foto", Toast.LENGTH_SHORT).show()
                                        }
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "Falha: ${e.message}", Toast.LENGTH_LONG).show()
                                    } finally {
                                        isProcessing = false
                                        statusBanner = null
                                    }
                                }
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(innerSize)
                            .clip(RoundedCornerShape(innerCorner))
                            .background(
                                when {
                                    selectedMode == CameraMode.VIDEO -> IosRed
                                    isProcessing -> Color(0xFF636366)
                                    else -> Color.White
                                }
                            )
                    )
                }

                // Trocar câmera (estilo iOS circular escuro)
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(IosSurface)
                        .clickable {
                            if (!isRecording) {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK) {
                                    CameraSelector.LENS_FACING_FRONT
                                } else {
                                    CameraSelector.LENS_FACING_BACK
                                }
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Rounded.Cameraswitch,
                        contentDescription = "Trocar Câmera",
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun TopCircleIcon(
    active: Boolean,
    onClick: () -> Unit,
    content: @Composable () -> Unit
) {
    Box(
        modifier = Modifier
            .size(34.dp)
            .clip(CircleShape)
            .background(if (active) Color(0xFF2C2C2E) else IosGlass)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        content()
    }
}

@Composable
private fun LiveHistogramView(bins: FloatArray, modifier: Modifier = Modifier) {
    Canvas(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0x99000000))
            .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(8.dp))
            .padding(3.dp)
    ) {
        if (bins.isEmpty()) return@Canvas
        val barW = size.width / bins.size
        for (i in bins.indices) {
            val h = bins[i].coerceIn(0f, 1f) * size.height
            drawRect(
                color = Color(0xDDFFFFFF),
                topLeft = Offset(i * barW, size.height - h),
                size = Size(barW, h)
            )
        }
    }
}

@Composable
private fun CompactProBar(
    capabilities: HardwareCapabilities,
    params: ProParameters,
    activeTool: ProTool,
    onSelectTool: (ProTool) -> Unit,
    onParamsChange: (ProParameters) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(IosSurface)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            ProTool.entries.forEach { tool ->
                val selected = tool == activeTool
                val enabled = when (tool) {
                    ProTool.ISO, ProTool.SHUTTER -> capabilities.supportsManualSensor
                    else -> true
                }
                Text(
                    text = tool.label,
                    color = when {
                        !enabled -> Color(0xFF48484A)
                        selected -> Color.Black
                        else -> Color.White
                    },
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(if (selected && enabled) IosYellow else Color(0xFF2C2C2E))
                        .clickable(enabled = enabled) { onSelectTool(tool) }
                        .padding(horizontal = 14.dp, vertical = 5.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        when (activeTool) {
            ProTool.EV -> {
                val evRange = capabilities.evRange
                if (evRange.upper > evRange.lower) {
                    Text(
                        text = "Exposição: ${"%+.1f".format(params.evIndex * capabilities.evStep)} EV",
                        color = IosYellow,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Slider(
                        value = params.evIndex.toFloat(),
                        onValueChange = {
                            onParamsChange(params.copy(isManualExposure = false, evIndex = it.toInt()))
                        },
                        valueRange = evRange.lower.toFloat()..evRange.upper.toFloat(),
                        colors = SliderDefaults.colors(thumbColor = IosYellow, activeTrackColor = IosYellow),
                        modifier = Modifier.height(28.dp)
                    )
                }
            }
            ProTool.ISO -> {
                val isoRange = capabilities.isoRange
                if (isoRange != null) {
                    val isoMax = isoRange.upper.coerceAtMost(3200)
                    if (isoMax > isoRange.lower) {
                        val currentIso = (params.iso ?: isoRange.lower).coerceIn(isoRange.lower, isoMax)
                        Text("ISO: $currentIso", color = IosYellow, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                        Slider(
                            value = currentIso.toFloat(),
                            onValueChange = {
                                onParamsChange(
                                    params.copy(
                                        isManualExposure = true,
                                        iso = it.toInt(),
                                        shutterSpeedNs = params.shutterSpeedNs ?: 16_000_000L
                                    )
                                )
                            },
                            valueRange = isoRange.lower.toFloat()..isoMax.toFloat(),
                            colors = SliderDefaults.colors(thumbColor = IosYellow, activeTrackColor = IosYellow),
                            modifier = Modifier.height(28.dp)
                        )
                    }
                }
            }
            ProTool.SHUTTER -> {
                val expRange = capabilities.exposureTimeRangeNs
                if (expRange != null) {
                    val minNs = expRange.lower.coerceAtLeast(100_000L)
                    val maxNs = expRange.upper.coerceAtMost(250_000_000L)
                    if (maxNs > minNs) {
                        val currentNs = (params.shutterSpeedNs ?: 16_000_000L).coerceIn(minNs, maxNs)
                        val denom = (1_000_000_000L / currentNs.coerceAtLeast(1L)).coerceAtLeast(1L)
                        Text("Obturador: 1/${denom}s", color = IosYellow, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                        Slider(
                            value = currentNs.toFloat(),
                            onValueChange = {
                                onParamsChange(
                                    params.copy(
                                        isManualExposure = true,
                                        iso = params.iso ?: (capabilities.isoRange?.lower ?: 100),
                                        shutterSpeedNs = it.toLong()
                                    )
                                )
                            },
                            valueRange = minNs.toFloat()..maxNs.toFloat(),
                            colors = SliderDefaults.colors(thumbColor = IosYellow, activeTrackColor = IosYellow),
                            modifier = Modifier.height(28.dp)
                        )
                    }
                }
            }
            ProTool.WB -> {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp)
                ) {
                    val wbOptions = listOf(
                        "Auto" to CaptureRequest.CONTROL_AWB_MODE_AUTO,
                        "Luz Dia" to CaptureRequest.CONTROL_AWB_MODE_DAYLIGHT,
                        "Nublado" to CaptureRequest.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT,
                        "Quente" to CaptureRequest.CONTROL_AWB_MODE_INCANDESCENT,
                        "Frio" to CaptureRequest.CONTROL_AWB_MODE_FLUORESCENT
                    )
                    wbOptions.forEach { (label, mode) ->
                        val active = params.awbMode == mode
                        Text(
                            text = label,
                            color = if (active) Color.Black else Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(if (active) IosYellow else Color(0xFF2C2C2E))
                                .clickable { onParamsChange(params.copy(awbMode = mode)) }
                                .padding(horizontal = 12.dp, vertical = 5.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsOverlay(
    capabilities: HardwareCapabilities,
    saveAsPng: Boolean,
    jpegQuality: Int,
    onTogglePng: (Boolean) -> Unit,
    onQualityChange: (Int) -> Unit,
    onClose: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xCC000000))
            .clickable { onClose() },
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.88f)
                .clip(RoundedCornerShape(22.dp))
                .background(IosSurface)
                .border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(22.dp))
                .clickable(enabled = false) {}
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("Ajustes da Câmera", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(
                text = "Camera2: ${capabilities.hardwareLevelLabel}  •  Manual: ${if (capabilities.supportsManualSensor) "Sim" else "Limitado"}  •  RAW: ${if (capabilities.supportsRaw) "Sim" else "Não"}",
                color = Color(0xFF8E8E93),
                fontSize = 12.sp
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Salvar em PNG (sem perdas)", color = Color.White, fontSize = 14.sp)
                Switch(
                    checked = saveAsPng,
                    onCheckedChange = onTogglePng,
                    colors = SwitchDefaults.colors(checkedThumbColor = Color.Black, checkedTrackColor = IosYellow)
                )
            }

            if (!saveAsPng) {
                Text("Qualidade JPEG: $jpegQuality%", color = Color.White, fontSize = 14.sp)
                Slider(
                    value = jpegQuality.toFloat(),
                    onValueChange = { onQualityChange(it.toInt()) },
                    valueRange = 80f..100f,
                    colors = SliderDefaults.colors(thumbColor = IosYellow, activeTrackColor = IosYellow)
                )
            }

            Text(
                text = "Concluído",
                color = IosYellow,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier
                    .align(Alignment.End)
                    .clickable { onClose() }
                    .padding(4.dp)
            )
        }
    }
}

private fun toggleVideoRecording(
    context: android.content.Context,
    videoCapture: VideoCapture<Recorder>?,
    activeRecording: Recording?,
    onRecordingChanged: (Recording?, Boolean) -> Unit
) {
    if (activeRecording != null) {
        activeRecording.stop()
        onRecordingChanged(null, false)
        return
    }
    val vc = videoCapture ?: return
    val name = "PROCAM_VID_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.mp4"
    val contentValues = ContentValues().apply {
        put(MediaStore.MediaColumns.DISPLAY_NAME, name)
        put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/ProCamAI")
        }
    }
    val outputOptions = MediaStoreOutputOptions.Builder(
        context.contentResolver,
        MediaStore.Video.Media.EXTERNAL_CONTENT_URI
    ).setContentValues(contentValues).build()

    var pending = vc.output.prepareRecording(context, outputOptions)
    if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
        pending = pending.withAudioEnabled()
    }
    val recording = pending.start(ContextCompat.getMainExecutor(context)) { event ->
        if (event is VideoRecordEvent.Finalize) {
            onRecordingChanged(null, false)
            if (!event.hasError()) {
                Toast.makeText(context, "Vídeo salvo em Movies/ProCamAI", Toast.LENGTH_SHORT).show()
            }
        }
    }
    onRecordingChanged(recording, true)
}

@Composable
private fun ProcessingPillOverlay(
    visible: Boolean,
    isProcessing: Boolean,
    statusBanner: String?,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(),
        exit = fadeOut(),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier
                .clip(CircleShape)
                .background(Color(0xCC1C1C1E))
                .border(1.dp, Color(0x33FFFFFF), CircleShape)
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (isProcessing) {
                CircularProgressIndicator(
                    color = IosYellow,
                    strokeWidth = 2.dp,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
            }
            Text(
                text = statusBanner ?: "Processando...",
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}
