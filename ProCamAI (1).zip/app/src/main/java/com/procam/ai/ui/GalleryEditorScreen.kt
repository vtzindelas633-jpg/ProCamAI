package com.procam.ai.ui

import android.graphics.Bitmap
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.procam.ai.processing.ComputationalPipeline
import com.procam.ai.processing.EditAdjustments
import com.procam.ai.storage.GalleryItem
import com.procam.ai.storage.MediaStoreSaver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val EditorYellow = Color(0xFFFFD60A)
private val EditorSurface = Color(0xFF1C1C1E)

private enum class EditTool(val label: String) {
    HDR("SMART HDR"),
    EXPOSURE("EXPOSIÇÃO"),
    CONTRAST("CONTRASTE"),
    SHADOWS("SOMBRAS"),
    SATURATION("SATURAÇÃO"),
    WARMTH("CALOR"),
    SHARPNESS("NITIDEZ")
}

@Composable
fun GalleryEditorScreen(
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var items by remember { mutableStateOf<List<GalleryItem>>(emptyList()) }
    var selectedItem by remember { mutableStateOf<GalleryItem?>(null) }
    var originalBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var editedBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var adjustments by remember { mutableStateOf(EditAdjustments()) }
    var activeTool by remember { mutableStateOf(EditTool.EXPOSURE) }
    var showingBefore by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        items = withContext(Dispatchers.IO) { MediaStoreSaver.loadRecentPhotos(context) }
    }

    LaunchedEffect(selectedItem) {
        val item = selectedItem ?: return@LaunchedEffect
        adjustments = EditAdjustments()
        val bmp = withContext(Dispatchers.IO) { MediaStoreSaver.decodeBitmapFromUri(context, item.uri, 1280) }
        originalBitmap = bmp
        editedBitmap = bmp
    }

    LaunchedEffect(adjustments, originalBitmap) {
        val orig = originalBitmap ?: return@LaunchedEffect
        editedBitmap = withContext(Dispatchers.Default) {
            ComputationalPipeline.applyEditorAdjustments(orig, adjustments)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        // Barra superior estilo Fotos do iOS
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = {
                if (selectedItem != null) {
                    selectedItem = null
                    originalBitmap = null
                    editedBitmap = null
                } else {
                    onBack()
                }
            }) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Voltar", tint = Color.White)
            }

            Text(
                text = if (selectedItem == null) "Galeria" else "Editar",
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold
            )

            if (selectedItem != null && editedBitmap != null) {
                Text(
                    text = "Salvar",
                    color = EditorYellow,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clip(CircleShape)
                        .clickable {
                            val bmpToSave = editedBitmap ?: return@clickable
                            scope.launch {
                                val uri = withContext(Dispatchers.IO) {
                                    MediaStoreSaver.saveBitmap(context, bmpToSave, prefix = "PROCAM_EDIT", quality = 98)
                                }
                                Toast.makeText(
                                    context,
                                    if (uri != null) "Foto editada salva!" else "Erro ao salvar",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                )
            } else {
                Spacer(modifier = Modifier.padding(24.dp))
            }
        }

        if (selectedItem == null) {
            if (items.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Nenhuma foto encontrada.", color = Color(0xFF8E8E93))
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    modifier = Modifier.fillMaxSize().padding(2.dp),
                    horizontalArrangement = Arrangement.spacedBy(2.dp),
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    items(items) { item ->
                        GalleryThumb(item = item, onClick = { selectedItem = item })
                    }
                }
            }
        } else {
            val displayBmp = if (showingBefore) originalBitmap else editedBitmap
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(Color.Black)
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onPress = {
                                showingBefore = true
                                tryAwaitRelease()
                                showingBefore = false
                            }
                        )
                    },
                contentAlignment = Alignment.Center
            ) {
                displayBmp?.let { bmp ->
                    Image(
                        bitmap = bmp.asImageBitmap(),
                        contentDescription = "Preview",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                Text(
                    text = if (showingBefore) "ORIGINAL" else "Segure para comparar",
                    color = if (showingBefore) Color.Black else Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(10.dp)
                        .clip(CircleShape)
                        .background(if (showingBefore) EditorYellow else Color(0x991C1C1E))
                        .padding(horizontal = 12.dp, vertical = 5.dp)
                )
            }

            // Barra de ferramentas limpa estilo Fotos do iOS
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(EditorSurface)
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Controle único ativo
                when (activeTool) {
                    EditTool.HDR -> {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Smart HDR Natural", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                            Text(
                                text = if (adjustments.applyHdrBoost) "ATIVADO" else "ATIVAR",
                                color = if (adjustments.applyHdrBoost) Color.Black else EditorYellow,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .background(if (adjustments.applyHdrBoost) EditorYellow else Color(0xFF2C2C2E))
                                    .clickable {
                                        adjustments = adjustments.copy(applyHdrBoost = !adjustments.applyHdrBoost)
                                    }
                                    .padding(horizontal = 14.dp, vertical = 6.dp)
                            )
                        }
                    }
                    EditTool.EXPOSURE -> SingleEditorSlider("Exposição", adjustments.exposure, -1f..1f) {
                        adjustments = adjustments.copy(exposure = it)
                    }
                    EditTool.CONTRAST -> SingleEditorSlider("Contraste", adjustments.contrast, 0.6f..1.5f) {
                        adjustments = adjustments.copy(contrast = it)
                    }
                    EditTool.SHADOWS -> SingleEditorSlider("Sombras", adjustments.shadowsHighlights, 0f..1f) {
                        adjustments = adjustments.copy(shadowsHighlights = it)
                    }
                    EditTool.SATURATION -> SingleEditorSlider("Saturação", adjustments.saturation, 0f..1.8f) {
                        adjustments = adjustments.copy(saturation = it)
                    }
                    EditTool.WARMTH -> SingleEditorSlider("Calor", adjustments.temperature, -1f..1f) {
                        adjustments = adjustments.copy(temperature = it)
                    }
                    EditTool.SHARPNESS -> SingleEditorSlider("Nitidez", adjustments.sharpness, 0f..1f) {
                        adjustments = adjustments.copy(sharpness = it)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Carrossel de ferramentas
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    EditTool.entries.forEach { tool ->
                        val selected = tool == activeTool
                        Text(
                            text = tool.label,
                            color = if (selected) Color.Black else Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(if (selected) EditorYellow else Color(0xFF2C2C2E))
                                .clickable { activeTool = tool }
                                .padding(horizontal = 14.dp, vertical = 7.dp)
                        )
                    }

                    Text(
                        text = "REDEFINIR",
                        color = Color(0xFFFF453A),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(Color(0xFF2C2C2E))
                            .clickable { adjustments = EditAdjustments() }
                            .padding(horizontal = 14.dp, vertical = 7.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun GalleryThumb(item: GalleryItem, onClick: () -> Unit) {
    val context = LocalContext.current
    var thumb by remember(item.uri) { mutableStateOf<Bitmap?>(null) }

    LaunchedEffect(item.uri) {
        thumb = withContext(Dispatchers.IO) {
            MediaStoreSaver.decodeBitmapFromUri(context, item.uri, 280)
        }
    }

    Box(
        modifier = Modifier
            .aspectRatio(1f)
            .background(Color(0xFF1C1C1E))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        thumb?.let {
            Image(
                bitmap = it.asImageBitmap(),
                contentDescription = item.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

@Composable
private fun SingleEditorSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, color = Color(0xFF8E8E93), fontSize = 12.sp, fontWeight = FontWeight.Medium)
            Text("${"%.2f".format(value)}", color = EditorYellow, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = range,
            colors = SliderDefaults.colors(thumbColor = EditorYellow, activeTrackColor = EditorYellow),
            modifier = Modifier.height(34.dp)
        )
    }
}
