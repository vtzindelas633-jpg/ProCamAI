# ProCam AI — Câmera Computacional Android

Aplicativo Android nativo em Kotlin com CameraX + Camera2 Interop, processamento computacional via OpenCV (HDR Multi-Frame, Modo Noturno, Tone Mapping CLAHE), detecção de rostos e análise de cena em tempo real com ML Kit, controles PRO manuais adaptados ao hardware real e galeria com editor integrado.

## Como compilar o APK pelo GitHub (sem PC)

1. Crie um repositório no GitHub (ex: `ProCamAI`).
2. Extraia este `.zip` e envie todos os arquivos e pastas (incluindo `.github/workflows/build-apk.yml`) para a branch `main`.
3. Abra a aba **Actions** no repositório.
4. Aguarde o workflow **Build ProCam AI APK** ficar verde (3 a 5 minutos).
5. Entre no build concluído, role até **Artifacts** e baixe `ProCamAI-APK`.
6. Extraia o arquivo baixado e instale o `app-debug.apk` no seu Android.
