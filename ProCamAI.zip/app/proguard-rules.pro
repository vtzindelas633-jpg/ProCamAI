# ProCam AI ProGuard Rules
-keep class org.opencv.** { *; }
