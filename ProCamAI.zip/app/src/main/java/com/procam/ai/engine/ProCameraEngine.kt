package com.procam.ai.engine

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.hardware.camera2.CaptureRequest
import androidx.annotation.OptIn
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.Camera
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.concurrent.Executor
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

data class ProParameters(
    val isManualExposure: Boolean = false,
    val iso: Int? = null,
    val shutterSpeedNs: Long? = null,
    val focusDistance: Float? = null,
    val evIndex: Int = 0,
    val awbMode: Int = CaptureRequest.CONTROL_AWB_MODE_AUTO
)

class ProCameraEngine(
    private val camera: Camera,
    private val imageCapture: ImageCapture,
    private val executor: Executor
) {

    @OptIn(ExperimentalCamera2Interop::class)
    fun applyProParameters(params: ProParameters) {
        val c2Control = Camera2CameraControl.from(camera.cameraControl)
        val builder = CaptureRequestOptions.Builder()
            .setCaptureRequestOption(CaptureRequest.CONTROL_AWB_MODE, params.awbMode)

        if (params.isManualExposure && params.iso != null && params.shutterSpeedNs != null) {
            builder
                .setCaptureRequestOption(
                    CaptureRequest.CONTROL_AE_MODE,
                    CaptureRequest.CONTROL_AE_MODE_OFF
                )
                .setCaptureRequestOption(CaptureRequest.SENSOR_SENSITIVITY, params.iso)
                .setCaptureRequestOption(CaptureRequest.SENSOR_EXPOSURE_TIME, params.shutterSpeedNs)
        } else {
            builder.setCaptureRequestOption(
                CaptureRequest.CONTROL_AE_MODE,
                CaptureRequest.CONTROL_AE_MODE_ON
            )
            val range = camera.cameraInfo.exposureState.exposureCompensationRange
            val clampedEv = params.evIndex.coerceIn(range.lower, range.upper)
            camera.cameraControl.setExposureCompensationIndex(clampedEv)
        }

        if (params.focusDistance != null) {
            builder
                .setCaptureRequestOption(
                    CaptureRequest.CONTROL_AF_MODE,
                    CaptureRequest.CONTROL_AF_MODE_OFF
                )
                .setCaptureRequestOption(CaptureRequest.LENS_FOCUS_DISTANCE, params.focusDistance)
        } else {
            builder.setCaptureRequestOption(
                CaptureRequest.CONTROL_AF_MODE,
                CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE
            )
        }

        c2Control.captureRequestOptions = builder.build()
    }

    /**
     * Captura 3 exposições reais (-EV, 0, +EV) para fusão HDR computacional.
     */
    suspend fun captureHdrBracket(evStepOffset: Int = 4): List<Bitmap> {
        val range = camera.cameraInfo.exposureState.exposureCompensationRange
        val originalEv = camera.cameraInfo.exposureState.exposureCompensationIndex

        val targets = listOf(
            (originalEv - evStepOffset).coerceIn(range.lower, range.upper),
            originalEv.coerceIn(range.lower, range.upper),
            (originalEv + evStepOffset).coerceIn(range.lower, range.upper)
        ).distinct()

        val frames = mutableListOf<Bitmap>()
        try {
            for (ev in targets) {
                camera.cameraControl.setExposureCompensationIndex(ev)
                delay(180L)
                frames.add(captureSingleBitmap())
            }
        } finally {
            camera.cameraControl.setExposureCompensationIndex(originalEv)
        }
        return frames
    }

    /**
     * Captura múltiplos frames consecutivos para empilhamento de Modo Noturno.
     */
    suspend fun captureNightBurst(frameCount: Int = 4): List<Bitmap> {
        val frames = mutableListOf<Bitmap>()
        repeat(frameCount) {
            frames.add(captureSingleBitmap())
            delay(60L)
        }
        return frames
    }

    suspend fun captureSingleBitmap(): Bitmap = suspendCancellableCoroutine { cont ->
        imageCapture.takePicture(executor, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                try {
                    val rotation = image.imageInfo.rotationDegrees
                    val buffer = image.planes[0].buffer
                    val bytes = ByteArray(buffer.remaining())
                    buffer.get(bytes)
                    image.close()

                    val rawBitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                        ?: throw IllegalStateException("Falha ao decodificar frame JPEG.")

                    val rotated = if (rotation != 0) {
                        val matrix = Matrix().apply { postRotate(rotation.toFloat()) }
                        Bitmap.createBitmap(
                            rawBitmap, 0, 0, rawBitmap.width, rawBitmap.height, matrix, true
                        ).also { rawBitmap.recycle() }
                    } else {
                        rawBitmap
                    }
                    cont.resume(rotated)
                } catch (e: Exception) {
                    image.close()
                    cont.resumeWithException(e)
                }
            }

            override fun onError(exception: ImageCaptureException) {
                cont.resumeWithException(exception)
            }
        })
    }
}
