package com.procam.ai.processing

import android.graphics.Bitmap
import android.graphics.RectF
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Point
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import org.opencv.photo.Photo

data class EditAdjustments(
    val exposure: Float = 0f,       // -1.0 .. +1.0
    val contrast: Float = 1f,       // 0.5 .. 1.6
    val saturation: Float = 1f,     // 0.0 .. 1.8
    val temperature: Float = 0f,    // -1.0 (frio) .. +1.0 (quente)
    val shadowsHighlights: Float = 0f, // 0.0 .. 1.0 (CLAHE boost)
    val sharpness: Float = 0f,      // 0.0 .. 1.0
    val applyHdrBoost: Boolean = false
)

object ComputationalPipeline {

    @Volatile
    var isOpenCvReady: Boolean = false

    /**
     * Pipeline completo para HDR Multi-Frame com alinhamento e fusão Mertens.
     */
    fun processHdrStack(
        frames: List<Bitmap>,
        applyDenoise: Boolean,
        sharpenStrength: Double = 0.32
    ): Bitmap {
        require(frames.isNotEmpty()) { "Lista de frames vazia." }
        if (!isOpenCvReady) return frames[frames.size / 2]

        val mats = frames.map { bitmapToBgr(it) }
        val baseBgr: Mat = if (mats.size > 1) {
            val alignMTB = Photo.createAlignMTB()
            alignMTB.process(mats, mats)

            val fused32F = Mat()
            val mergeMertens = Photo.createMergeMertens(1.0f, 1.0f, 0.25f)
            mergeMertens.process(mats, fused32F)
            mats.forEach { it.release() }

            val merged8U = Mat()
            fused32F.convertTo(merged8U, CvType.CV_8UC3, 255.0)
            fused32F.release()
            merged8U
        } else {
            mats[0]
        }

        val denoised = applyAdaptiveDenoise(baseBgr, applyDenoise)
        baseBgr.release()

        val toneMapped = applyLabClahe(denoised, clipLimit = 1.8)
        denoised.release()

        val sharpened = applyUnsharpMask(toneMapped, sharpenStrength)
        toneMapped.release()

        return bgrToBitmapAndRelease(sharpened)
    }

    /**
     * Pipeline de Modo Noturno: alinha múltiplos frames e calcula a média temporal
     * para reduzir drasticamente o ruído de sensor e recuperar sombras.
     */
    fun processNightStack(frames: List<Bitmap>): Bitmap {
        require(frames.isNotEmpty()) { "Lista de frames vazia." }
        if (!isOpenCvReady) return frames.first()

        val mats = frames.map { bitmapToBgr(it) }
        if (mats.size > 1) {
            val alignMTB = Photo.createAlignMTB()
            alignMTB.process(mats, mats)
        }

        val acc = Mat.zeros(mats[0].size(), CvType.CV_32FC3)
        val tmp = Mat()
        for (m in mats) {
            m.convertTo(tmp, CvType.CV_32FC3)
            Core.add(acc, tmp, acc)
            m.release()
        }
        tmp.release()

        val averaged = Mat()
        acc.convertTo(averaged, CvType.CV_8UC3, 1.0 / mats.size.toDouble())
        acc.release()

        val denoised = applyAdaptiveDenoise(averaged, enabled = true, strength = 6f)
        averaged.release()

        // Recuperação de sombras em LAB sem lavar os pretos
        val lifted = applyLabClahe(denoised, clipLimit = 2.4)
        denoised.release()

        val sharpened = applyUnsharpMask(lifted, amount = 0.28)
        lifted.release()

        return bgrToBitmapAndRelease(sharpened)
    }

    /**
     * Otimização inteligente de foto única (Auto + IA).
     */
    fun processAutoSmart(
        bitmap: Bitmap,
        isLowLight: Boolean,
        isBacklit: Boolean
    ): Bitmap {
        if (!isOpenCvReady) return bitmap
        val bgr = bitmapToBgr(bitmap)

        val denoised = applyAdaptiveDenoise(bgr, enabled = isLowLight, strength = 4f)
        bgr.release()

        val clip = when {
            isBacklit -> 2.2
            isLowLight -> 1.8
            else -> 1.3
        }
        val toneMapped = applyLabClahe(denoised, clipLimit = clip)
        denoised.release()

        val sharpened = applyUnsharpMask(toneMapped, amount = 0.25)
        toneMapped.release()

        return bgrToBitmapAndRelease(sharpened)
    }

    /**
     * Modo Retrato: preserva o assunto (rosto/torso detectado pela IA) nítido
     * e aplica desfoque bokeh progressivo no fundo.
     */
    fun processPortraitBokeh(
        bitmap: Bitmap,
        faces: List<RectF>,
        blurRadius: Double = 35.0
    ): Bitmap {
        if (!isOpenCvReady) return bitmap
        val bgr = bitmapToBgr(bitmap)
        val rows = bgr.rows()
        val cols = bgr.cols()

        val blurred = Mat()
        val kSize = (blurRadius.toInt() or 1).coerceAtLeast(15)
        Imgproc.GaussianBlur(bgr, blurred, Size(kSize.toDouble(), kSize.toDouble()), 0.0)

        // Cria máscara suave centrada no rosto detectado (ou centro da cena como fallback)
        val mask = Mat.zeros(rows, cols, CvType.CV_32FC1)
        if (faces.isNotEmpty()) {
            for (face in faces) {
                val cx = ((face.left + face.right) / 2f) * cols
                val cy = ((face.top + face.bottom) / 2f) * rows
                val rx = (face.width() * cols * 0.95f).coerceAtLeast(cols * 0.18f)
                val ry = (face.height() * rows * 1.45f).coerceAtLeast(rows * 0.22f)
                // Rosto + área de ombros/torso
                Imgproc.ellipse(
                    mask,
                    Point(cx.toDouble(), (cy + ry * 0.25).coerceAtMost(rows.toDouble())),
                    Size(rx.toDouble(), ry.toDouble()),
                    0.0, 0.0, 360.0,
                    Scalar(1.0),
                    -1
                )
            }
        } else {
            Imgproc.ellipse(
                mask,
                Point(cols * 0.5, rows * 0.48),
                Size(cols * 0.28, rows * 0.36),
                0.0, 0.0, 360.0,
                Scalar(1.0),
                -1
            )
        }

        // Suaviza transição da máscara para bokeh natural
        Imgproc.GaussianBlur(mask, mask, Size(101.0, 101.0), 0.0)

        val fgFloat = Mat()
        val bgFloat = Mat()
        bgr.convertTo(fgFloat, CvType.CV_32FC3)
        blurred.convertTo(bgFloat, CvType.CV_32FC3)

        val mask3 = Mat()
        Core.merge(listOf(mask, mask, mask), mask3)

        val invMask3 = Mat()
        Core.subtract(Mat.ones(mask3.size(), CvType.CV_32FC3), mask3, invMask3)

        val fgPart = Mat()
        val bgPart = Mat()
        Core.multiply(fgFloat, mask3, fgPart)
        Core.multiply(bgFloat, invMask3, bgPart)

        val combined32 = Mat()
        Core.add(fgPart, bgPart, combined32)
        val result8U = Mat()
        combined32.convertTo(result8U, CvType.CV_8UC3)

        bgr.release()
        blurred.release()
        mask.release()
        mask3.release()
        invMask3.release()
        fgFloat.release()
        bgFloat.release()
        fgPart.release()
        bgPart.release()
        combined32.release()

        return bgrToBitmapAndRelease(result8U)
    }

    /**
     * Editor não destrutivo da Galeria integrada.
     */
    fun applyEditorAdjustments(source: Bitmap, adj: EditAdjustments): Bitmap {
        if (!isOpenCvReady) return source
        var current = bitmapToBgr(source)

        // 1. Exposição e Contraste
        if (adj.exposure != 0f || adj.contrast != 1f) {
            val adjusted = Mat()
            val alpha = adj.contrast.toDouble()
            val beta = (adj.exposure * 65.0) + (1.0 - alpha) * 128.0
            current.convertTo(adjusted, CvType.CV_8UC3, alpha, beta)
            current.release()
            current = adjusted
        }

        // 2. Temperatura de cor (ajuste suave de canais B e R)
        if (adj.temperature != 0f) {
            val channels = ArrayList<Mat>(3)
            Core.split(current, channels)
            val delta = (adj.temperature * 28.0)
            Core.add(channels[2], Scalar(delta), channels[2])  // Vermelho
            Core.add(channels[0], Scalar(-delta), channels[0]) // Azul
            Core.merge(channels, current)
            channels.forEach { it.release() }
        }

        // 3. Saturação (espaço HSV)
        if (adj.saturation != 1f) {
            val hsv = Mat()
            Imgproc.cvtColor(current, hsv, Imgproc.COLOR_BGR2HSV)
            val channels = ArrayList<Mat>(3)
            Core.split(hsv, channels)
            channels[1].convertTo(channels[1], CvType.CV_8UC1, adj.saturation.toDouble(), 0.0)
            Core.merge(channels, hsv)
            val next = Mat()
            Imgproc.cvtColor(hsv, next, Imgproc.COLOR_HSV2BGR)
            channels.forEach { it.release() }
            hsv.release()
            current.release()
            current = next
        }

        // 4. Sombras/Realces ou HDR em foto única
        val claheStrength = if (adj.applyHdrBoost) {
            2.4
        } else if (adj.shadowsHighlights > 0.05f) {
            1.0 + adj.shadowsHighlights * 2.0
        } else {
            0.0
        }
        if (claheStrength > 0.0) {
            val next = applyLabClahe(current, clipLimit = claheStrength)
            current.release()
            current = next
        }

        // 5. Nitidez
        if (adj.sharpness > 0.02f) {
            val next = applyUnsharpMask(current, amount = adj.sharpness * 0.9)
            current.release()
            current = next
        }

        return bgrToBitmapAndRelease(current)
    }

    private fun applyAdaptiveDenoise(src: Mat, enabled: Boolean, strength: Float = 5f): Mat {
        val dst = Mat()
        if (enabled) {
            Photo.fastNlMeansDenoisingColored(src, dst, strength, strength, 5, 13)
        } else {
            src.copyTo(dst)
        }
        return dst
    }

    private fun applyLabClahe(src: Mat, clipLimit: Double): Mat {
        val lab = Mat()
        Imgproc.cvtColor(src, lab, Imgproc.COLOR_BGR2Lab)
        val channels = ArrayList<Mat>(3)
        Core.split(lab, channels)

        val clahe = Imgproc.createCLAHE(clipLimit, Size(8.0, 8.0))
        clahe.apply(channels[0], channels[0])

        Core.merge(channels, lab)
        val dst = Mat()
        Imgproc.cvtColor(lab, dst, Imgproc.COLOR_Lab2BGR)
        channels.forEach { it.release() }
        lab.release()
        return dst
    }

    private fun applyUnsharpMask(src: Mat, amount: Double): Mat {
        val blurred = Mat()
        Imgproc.GaussianBlur(src, blurred, Size(0.0, 0.0), 1.4)
        val dst = Mat()
        Core.addWeighted(src, 1.0 + amount, blurred, -amount, 0.0, dst)
        blurred.release()
        return dst
    }

    private fun bitmapToBgr(bitmap: Bitmap): Mat {
        val rgba = Mat()
        Utils.bitmapToMat(bitmap, rgba)
        val bgr = Mat()
        Imgproc.cvtColor(rgba, bgr, Imgproc.COLOR_RGBA2BGR)
        rgba.release()
        return bgr
    }

    private fun bgrToBitmapAndRelease(bgr: Mat): Bitmap {
        val rgba = Mat()
        Imgproc.cvtColor(bgr, rgba, Imgproc.COLOR_BGR2RGBA)
        bgr.release()
        val out = Bitmap.createBitmap(rgba.cols(), rgba.rows(), Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(rgba, out)
        rgba.release()
        return out
    }
}
