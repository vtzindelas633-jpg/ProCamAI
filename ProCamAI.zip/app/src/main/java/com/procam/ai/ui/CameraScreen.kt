package com.procam.ai.ui

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.hardware.camera2.CaptureRequest
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.view.MotionEvent
import android.widget.Toast
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.FlashAuto
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.HdrOn
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.procam.ai.ai.SceneIntelligenceAnalyzer
import com.procam.ai.ai.SceneTelemetry
import com.procam.ai.engine.ProCameraEngine
import com.procam.ai.engine.ProParameters
import com.procam.ai.hardware.CameraCapabilityManager
import com.procam.ai.hardware.HardwareCapabilities
import com.procam.ai.processing.ComputationalPipeline
import com.procam.ai.storage.MediaStoreSaver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

enum class CameraMode(val label: String) {
    AUTO("AUTO"),
    HDR("HDR"),
    PORTRAIT("RETRATO"),
    NIGHT("NOITE"),
    PRO("PRO"),
    VIDEO("VÍDEO")
}

@Composable
fun CameraScreen(
    onOpenGallery: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()

    val cameraExecutor = remember { Executors.newSingleThreadExecutor() }
    val analysisExecutor = remember { Executors.newSingleThreadExecutor() }

    var lensFacing by remember { mutableIntStateOf(CameraSelector.LENS_FACING_BACK) }
    var selectedMode by remember { mutableStateOf(CameraMode.AUTO) }
    var flashMode by remember { mutableIntStateOf(ImageCapture.FLASH_MODE_AUTO) }
    var aiEnabled by remember { mutableStateOf(true) }
    var showHistogram by remember { mutableStateOf(true) }
    var showSettings by remember { mutableStateOf(false) }
    var saveAsPng by remember { mutableStateOf(false) }
    var jpegQuality by remember { mutableIntStateOf(96) }

    var capabilities by remember { mutableStateOf(HardwareCapabilities()) }
    var telemetry by remember { mutableStateOf(SceneTelemetry()) }
    var isProcessing by remember { mutableStateOf(false) }
    var statusBanner by remember { mutableStateOf<String?>(null) }

    // Controles PRO
    var proParams by remember { mutableStateOf(ProParameters()) }
    var zoomRatio by remember { mutableFloatStateOf(1f) }

    // Vídeo
    var activeRecording by remember { mutableStateOf<Recording?>(null) }
    var isRecording by remember { mutableStateOf(false) }

    // Referências CameraX
    var cameraRef by remember { mutableStateOf<Camera?>(null) }
    var imageCaptureRef by remember { mutableStateOf<ImageCapture?>(null) }
    var videoCaptureRef by remember { mutableStateOf<VideoCapture<Recorder>?>(null) }
    var proEngineRef by remember { mutableStateOf<ProCameraEngine?>(null) }

    val previewView = remember {
        PreviewView(context).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
    }

    val analyzer = remember {
        SceneIntelligenceAnalyzer(
            isFrontCamera = { lensFacing == CameraSelector.LENS_FACING_FRONT },
            onTelemetry = { telemetry = it }
        )
    }

    DisposableEffect(Unit) {
        onDispose {
            activeRecording?.stop()
            analyzer.close()
            cameraExecutor.shutdown()
            analysisExecutor.shutdown()
        }
    }

    // Bind da câmera ao mudar lente ou modo (Vídeo vs Foto)
    LaunchedEffect(lensFacing, selectedMode == CameraMode.VIDEO) {
        val providerFuture = ProcessCameraProvider.getInstance(context)
        providerFuture.addListener({
            try {
                val cameraProvider = providerFuture.get()
                cameraProvider.unbindAll()

                val selector = CameraSelector.Builder()
                    .requireLensFacing(lensFacing)
                    .build()

                val preview = Preview.Builder().build().also {
                    it.surfaceProvider = previewView.surfaceProvider
                }

                val imageCapture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                    .setFlashMode(flashMode)
                    .build()

                val imageAnalysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                    .also { it.setAnalyzer(analysisExecutor, analyzer) }

                val camera = if (selectedMode == CameraMode.VIDEO) {
                    val recorder = Recorder.Builder()
                        .setQualitySelector(QualitySelector.from(Quality.HIGHEST))
                        .build()
                    val videoCapture = VideoCapture.withOutput(recorder)
                    videoCaptureRef = videoCapture
                    cameraProvider.bindToLifecycle(
                        lifecycleOwner, selector, preview, videoCapture
                    )
                } else {
                    videoCaptureRef = null
                    cameraProvider.bindToLifecycle(
                        lifecycleOwner, selector, preview, imageCapture, imageAnalysis
                    )
                }

                cameraRef = camera
                imageCaptureRef = imageCapture
                proEngineRef = ProCameraEngine(camera, imageCapture, cameraExecutor)
                capabilities = CameraCapabilityManager.probe(camera.cameraInfo)
                zoomRatio = 1f
            } catch (e: Exception) {
                Toast.makeText(context, "Erro ao iniciar câmera: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(context))
    }

    // Atualiza flash quando alterado
    LaunchedEffect(flashMode) {
        imageCaptureRef?.flashMode = flashMode
    }

    // Aplica parâmetros PRO quando modificados
    LaunchedEffect(proParams, selectedMode) {
        if (selectedMode == CameraMode.PRO) {
            proEngineRef?.applyProParameters(proParams)
        } else {
            proEngineRef?.applyProParameters(ProParameters())
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // 1. Viewfinder em tela cheia com toque para focar
        AndroidView(
            factory = {
                previewView.setOnTouchListener { view, event ->
                    if (event.action == MotionEvent.ACTION_UP) {
                        val factory = previewView.meteringPointFactory
                        val point = factory.createPoint(event.x, event.y)
                        val action = FocusMeteringAction.Builder(point).build()
                        cameraRef?.cameraControl?.startFocusAndMetering(action)
                        view.performClick()
                    }
                    true
                }
                previewView
            },
            modifier = Modifier.fillMaxSize()
        )

        // 2. Overlay de detecção de rostos da IA
        if (aiEnabled && telemetry.detectedFaces.isNotEmpty() && selectedMode != CameraMode.VIDEO) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                for (box in telemetry.detectedFaces) {
                    drawRect(
                        color = Color(0xFFFFD54F),
                        topLeft = Offset(box.left * size.width, box.top * size.height),
                        size = Size(box.width() * size.width, box.height() * size.height),
                        style = Stroke(width = 3f)
                    )
                }
            }
        }

        // 3. Barra superior (Flash, IA, Histograma, Configurações)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .background(Color(0x88000000))
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = {
                    flashMode = when (flashMode) {
                        ImageCapture.FLASH_MODE_AUTO -> ImageCapture.FLASH_MODE_ON
                        ImageCapture.FLASH_MODE_ON -> ImageCapture.FLASH_MODE_OFF
                        else -> ImageCapture.FLASH_MODE_AUTO
                    }
                }) {
                    val icon = when (flashMode) {
                        ImageCapture.FLASH_MODE_ON -> Icons.Default.FlashOn
                        ImageCapture.FLASH_MODE_OFF -> Icons.Default.FlashOff
                        else -> Icons.Default.FlashAuto
                    }
                    Icon(icon, contentDescription = "Flash", tint = Color.White)
                }

                IconButton(onClick = { aiEnabled = !aiEnabled }) {
                    Icon(
                        Icons.Default.AutoAwesome,
                        contentDescription = "IA",
                        tint = if (aiEnabled) Color(0xFF60A5FA) else Color.Gray
                    )
                }

                IconButton(onClick = {
                    selectedMode = if (selectedMode == CameraMode.HDR) CameraMode.AUTO else CameraMode.HDR
                }) {
                    Icon(
                        Icons.Default.HdrOn,
                        contentDescription = "HDR",
                        tint = if (selectedMode == CameraMode.HDR) Color(0xFFFFD54F) else Color.White
                    )
                }

                IconButton(onClick = { showHistogram = !showHistogram }) {
                    Icon(
                        Icons.Default.ShowChart,
                        contentDescription = "Histograma",
                        tint = if (showHistogram) Color(0xFF34D399) else Color.Gray
                    )
                }

                IconButton(onClick = { showSettings = !showSettings }) {
                    Icon(Icons.Default.Settings, contentDescription = "Configurações", tint = Color.White)
                }
            }

            // Badge de telemetria IA + Hardware + Histograma compacto
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 6.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (aiEnabled) {
                    Text(
                        text = "IA: ${telemetry.recommendedScene} • ${capabilities.hardwareLevelLabel}",
                        color = Color(0xFFE5E7EB),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0x99111827))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                } else {
                    Spacer(modifier = Modifier.width(8.dp))
                }

                if (showHistogram && selectedMode != CameraMode.VIDEO) {
                    LiveHistogramView(
                        bins = telemetry.histogram,
                        modifier = Modifier
                            .width(104.dp)
                            .height(34.dp)
                    )
                }
            }
        }

        // 4. Painel de Configurações Avançadas (overlay)
        if (showSettings) {
            SettingsOverlay(
                capabilities = capabilities,
                saveAsPng = saveAsPng,
                jpegQuality = jpegQuality,
                onTogglePng = { saveAsPng = it },
                onQualityChange = { jpegQuality = it },
                onClose = { showSettings = false }
            )
        }

        // 5. Indicador de processamento computacional
        if (isProcessing || statusBanner != null) {
            Row(
                modifier = Modifier
                    .align(Alignment.Center)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xCC000000))
                    .padding(horizontal = 18.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (isProcessing) {
                    CircularProgressIndicator(
                        color = Color(0xFF60A5FA),
                        strokeWidth = 2.5.dp,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                }
                Text(
                    text = statusBanner ?: "Processando imagem...",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        // 6. Controles Inferiores (Zoom, Painel PRO, Seletor de Modos, Disparo)
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(Color(0xBB000000))
                .padding(bottom = 22.dp, top = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Painel PRO real (adaptado ao hardware)
            if (selectedMode == CameraMode.PRO) {
                ProControlsPanel(
                    capabilities = capabilities,
                    params = proParams,
                    onParamsChange = { proParams = it }
                )
            }

            // Botões rápidos de Zoom
            if (capabilities.maxZoom > 1.1f) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.padding(bottom = 8.dp)
                ) {
                    val steps = listOf(1f, 2f, 4f).filter { it <= capabilities.maxZoom }
                    for (z in steps) {
                        val active = kotlin.math.abs(zoomRatio - z) < 0.2f
                        Text(
                            text = "${z.toInt()}x",
                            color = if (active) Color(0xFFFFD54F) else Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(if (active) Color(0xAA1F2937) else Color(0x66000000))
                                .clickable {
                                    zoomRatio = z
                                    cameraRef?.cameraControl?.setZoomRatio(z)
                                }
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                }
            }

            // Seletor de Modos
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(18.dp, Alignment.CenterHorizontally)
            ) {
                CameraMode.entries.forEach { mode ->
                    val selected = mode == selectedMode
                    Text(
                        text = mode.label,
                        color = if (selected) Color(0xFFFFD54F) else Color(0xFF9CA3AF),
                        fontSize = 13.sp,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                        modifier = Modifier
                            .clickable {
                                if (!isRecording) selectedMode = mode
                            }
                            .padding(vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Linha principal: Galeria | Botão de Disparo | Trocar Câmera
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 34.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onOpenGallery,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF1F2937))
                ) {
                    Icon(Icons.Default.PhotoLibrary, contentDescription = "Galeria", tint = Color.White)
                }

                // Botão do obturador / gravação
                Box(
                    modifier = Modifier
                        .size(74.dp)
                        .clip(CircleShape)
                        .border(4.dp, Color.White, CircleShape)
                        .padding(6.dp)
                        .clip(CircleShape)
                        .background(
                            when {
                                selectedMode == CameraMode.VIDEO && isRecording -> Color(0xFFEF4444)
                                selectedMode == CameraMode.VIDEO -> Color(0xFFDC2626)
                                isProcessing -> Color.Gray
                                else -> Color.White
                            }
                        )
                        .clickable(enabled = !isProcessing) {
                            if (selectedMode == CameraMode.VIDEO) {
                                toggleVideoRecording(
                                    context = context,
                                    videoCapture = videoCaptureRef,
                                    activeRecording = activeRecording,
                                    onRecordingChanged = { rec, recording ->
                                        activeRecording = rec
                                        isRecording = recording
                                    }
                                )
                            } else {
                                val engine = proEngineRef ?: return@clickable
                                scope.launch {
                                    isProcessing = true
                                    try {
                                        val format = if (saveAsPng) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG
                                        val finalBitmap = when (selectedMode) {
                                            CameraMode.HDR -> {
                                                statusBanner = "Capturando HDR (3 exposições)..."
                                                val stack = engine.captureHdrBracket()
                                                statusBanner = "Fundindo HDR e Tone Mapping..."
                                                withContext(Dispatchers.Default) {
                                                    ComputationalPipeline.processHdrStack(
                                                        frames = stack,
                                                        applyDenoise = telemetry.isLowLight
                                                    )
                                                }
                                            }
                                            CameraMode.NIGHT -> {
                                                statusBanner = "Capturando Modo Noturno (4 frames)..."
                                                val stack = engine.captureNightBurst(4)
                                                statusBanner = "Alinhando e reduzindo ruído..."
                                                withContext(Dispatchers.Default) {
                                                    ComputationalPipeline.processNightStack(stack)
                                                }
                                            }
                                            CameraMode.PORTRAIT -> {
                                                statusBanner = "Capturando Retrato..."
                                                val bmp = engine.captureSingleBitmap()
                                                statusBanner = "Aplicando desfoque bokeh..."
                                                withContext(Dispatchers.Default) {
                                                    ComputationalPipeline.processPortraitBokeh(
                                                        bitmap = bmp,
                                                        faces = telemetry.detectedFaces
                                                    )
                                                }
                                            }
                                            CameraMode.PRO -> {
                                                statusBanner = "Capturando PRO..."
                                                engine.captureSingleBitmap()
                                            }
                                            else -> {
                                                if (aiEnabled && telemetry.isBacklit) {
                                                    statusBanner = "IA: Contraluz detectado (HDR)..."
                                                    val stack = engine.captureHdrBracket(3)
                                                    withContext(Dispatchers.Default) {
                                                        ComputationalPipeline.processHdrStack(stack, false)
                                                    }
                                                } else {
                                                    statusBanner = "Capturando..."
                                                    val bmp = engine.captureSingleBitmap()
                                                    if (aiEnabled) {
                                                        withContext(Dispatchers.Default) {
                                                            ComputationalPipeline.processAutoSmart(
                                                                bmp,
                                                                telemetry.isLowLight,
                                                                telemetry.isBacklit
                                                            )
                                                        }
                                                    } else bmp
                                                }
                                            }
                                        }

                                        statusBanner = "Salvando na galeria..."
                                        val savedUri = withContext(Dispatchers.IO) {
                                            MediaStoreSaver.saveBitmap(
                                                context = context,
                                                bitmap = finalBitmap,
                                                prefix = "PROCAM_${selectedMode.name}",
                                                format = format,
                                                quality = jpegQuality
                                            )
                                        }
                                        Toast.makeText(
                                            context,
                                            if (savedUri != null) "Foto salva em DCIM/ProCamAI" else "Erro ao salvar foto",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "Falha na captura: ${e.message}", Toast.LENGTH_LONG).show()
                                    } finally {
                                        isProcessing = false
                                        statusBanner = null
                                    }
                                }
                            }
                        }
                )

                IconButton(
                    onClick = {
                        if (!isRecording) {
                            lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK) {
                                CameraSelector.LENS_FACING_FRONT
                            } else {
                                CameraSelector.LENS_FACING_BACK
                            }
                        }
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF1F2937))
                ) {
                    Icon(Icons.Default.Cameraswitch, contentDescription = "Trocar Câmera", tint = Color.White)
                }
            }
        }
    }
}

@Composable
private fun LiveHistogramView(bins: FloatArray, modifier: Modifier = Modifier) {
    Canvas(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(Color(0x99000000))
            .border(1.dp, Color(0x44FFFFFF), RoundedCornerShape(6.dp))
            .padding(2.dp)
    ) {
        if (bins.isEmpty()) return@Canvas
        val barW = size.width / bins.size
        for (i in bins.indices) {
            val h = bins[i].coerceIn(0f, 1f) * size.height
            drawRect(
                color = Color(0xCC93C5FD),
                topLeft = Offset(i * barW, size.height - h),
                size = Size(barW, h)
            )
        }
    }
}

@Composable
private fun ProControlsPanel(
    capabilities: HardwareCapabilities,
    params: ProParameters,
    onParamsChange: (ProParameters) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xCC111827))
            .padding(10.dp)
    ) {
        // EV (sempre disponível na maioria dos aparelhos)
        val evRange = capabilities.evRange
        if (evRange.upper > evRange.lower) {
            Text(
                text = "EV: ${"%.1f".format(params.evIndex * capabilities.evStep)}",
                color = Color.White,
                fontSize = 11.sp
            )
            Slider(
                value = params.evIndex.toFloat(),
                onValueChange = {
                    onParamsChange(params.copy(isManualExposure = false, evIndex = it.toInt()))
                },
                valueRange = evRange.lower.toFloat()..evRange.upper.toFloat(),
                colors = SliderDefaults.colors(thumbColor = Color(0xFFFFD54F), activeTrackColor = Color(0xFFFFD54F)),
                modifier = Modifier.height(26.dp)
            )
        }

        // ISO e Obturador reais se o sensor suportar MANUAL_SENSOR
        if (capabilities.supportsManualSensor && capabilities.isoRange != null && capabilities.exposureTimeRangeNs != null) {
            val isoRange = capabilities.isoRange
            val isoMax = isoRange.upper.coerceAtMost(3200)
            if (isoMax > isoRange.lower) {
                val currentIso = (params.iso ?: isoRange.lower).coerceIn(isoRange.lower, isoMax)
                Text(text = "ISO: $currentIso", color = Color.White, fontSize = 11.sp)
                Slider(
                    value = currentIso.toFloat(),
                    onValueChange = {
                        onParamsChange(
                            params.copy(
                                isManualExposure = true,
                                iso = it.toInt(),
                                shutterSpeedNs = params.shutterSpeedNs ?: 16_000_000L
                            )
                        )
                    },
                    valueRange = isoRange.lower.toFloat()..isoMax.toFloat(),
                    modifier = Modifier.height(26.dp)
                )
            }

            val minNs = capabilities.exposureTimeRangeNs.lower.coerceAtLeast(100_000L)
            val maxNs = capabilities.exposureTimeRangeNs.upper.coerceAtMost(250_000_000L)
            if (maxNs > minNs) {
                val currentNs = (params.shutterSpeedNs ?: 16_000_000L).coerceIn(minNs, maxNs)
                val denom = (1_000_000_000L / currentNs.coerceAtLeast(1L)).coerceAtLeast(1L)
                Text(text = "Obturador: 1/${denom}s", color = Color.White, fontSize = 11.sp)
                Slider(
                    value = currentNs.toFloat(),
                    onValueChange = {
                        onParamsChange(
                            params.copy(
                                isManualExposure = true,
                                iso = params.iso ?: isoRange.lower,
                                shutterSpeedNs = it.toLong()
                            )
                        )
                    },
                    valueRange = minNs.toFloat()..maxNs.toFloat(),
                    modifier = Modifier.height(26.dp)
                )
            }
        } else {
            Text(
                text = "Hardware ${capabilities.hardwareLevelLabel}: ISO/Obturador manual bloqueado pelo fabricante (EV e WB ativos).",
                color = Color(0xFF9CA3AF),
                fontSize = 10.sp
            )
        }

        // Balanço de Branco
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.horizontalScroll(rememberScrollState())
        ) {
            val wbOptions = listOf(
                "WB Auto" to CaptureRequest.CONTROL_AWB_MODE_AUTO,
                "Luz Dia" to CaptureRequest.CONTROL_AWB_MODE_DAYLIGHT,
                "Nublado" to CaptureRequest.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT,
                "Tungstênio" to CaptureRequest.CONTROL_AWB_MODE_INCANDESCENT,
                "Fluorescente" to CaptureRequest.CONTROL_AWB_MODE_FLUORESCENT
            )
            wbOptions.forEach { (label, mode) ->
                val active = params.awbMode == mode
                Text(
                    text = label,
                    color = if (active) Color.Black else Color.White,
                    fontSize = 11.sp,
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (active) Color(0xFFFFD54F) else Color(0xFF374151))
                        .clickable { onParamsChange(params.copy(awbMode = mode)) }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }
    }
}

@Composable
private fun SettingsOverlay(
    capabilities: HardwareCapabilities,
    saveAsPng: Boolean,
    jpegQuality: Int,
    onTogglePng: (Boolean) -> Unit,
    onQualityChange: (Int) -> Unit,
    onClose: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xCC000000))
            .clickable { onClose() },
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.88f)
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xFF111827))
                .clickable(enabled = false) {}
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Configurações & Hardware", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Text(
                text = "Nível Camera2: ${capabilities.hardwareLevelLabel} | Manual: ${if (capabilities.supportsManualSensor) "Sim" else "Não"} | RAW: ${if (capabilities.supportsRaw) "Sim" else "Não"}",
                color = Color(0xFF9CA3AF),
                fontSize = 12.sp
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Salvar em PNG (sem compressão)", color = Color.White, fontSize = 13.sp)
                Switch(checked = saveAsPng, onCheckedChange = onTogglePng)
            }

            if (!saveAsPng) {
                Text("Qualidade JPEG: $jpegQuality%", color = Color.White, fontSize = 13.sp)
                Slider(
                    value = jpegQuality.toFloat(),
                    onValueChange = { onQualityChange(it.toInt()) },
                    valueRange = 80f..100f
                )
            }

            Text(
                text = "FECHAR",
                color = Color(0xFF60A5FA),
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .align(Alignment.End)
                    .clickable { onClose() }
                    .padding(6.dp)
            )
        }
    }
}

private fun toggleVideoRecording(
    context: android.content.Context,
    videoCapture: VideoCapture<Recorder>?,
    activeRecording: Recording?,
    onRecordingChanged: (Recording?, Boolean) -> Unit
) {
    if (activeRecording != null) {
        activeRecording.stop()
        onRecordingChanged(null, false)
        return
    }
    val vc = videoCapture ?: return
    val name = "PROCAM_VID_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.mp4"
    val contentValues = ContentValues().apply {
        put(MediaStore.MediaColumns.DISPLAY_NAME, name)
        put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/ProCamAI")
        }
    }
    val outputOptions = MediaStoreOutputOptions.Builder(
        context.contentResolver,
        MediaStore.Video.Media.EXTERNAL_CONTENT_URI
    ).setContentValues(contentValues).build()

    var pending = vc.output.prepareRecording(context, outputOptions)
    if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
        pending = pending.withAudioEnabled()
    }
    val recording = pending.start(ContextCompat.getMainExecutor(context)) { event ->
        if (event is VideoRecordEvent.Finalize) {
            onRecordingChanged(null, false)
            if (!event.hasError()) {
                Toast.makeText(context, "Vídeo salvo em Movies/ProCamAI", Toast.LENGTH_SHORT).show()
            }
        }
    }
    onRecordingChanged(recording, true)
}
