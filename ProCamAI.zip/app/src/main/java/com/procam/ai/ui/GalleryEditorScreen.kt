package com.procam.ai.ui

import android.graphics.Bitmap
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.procam.ai.processing.ComputationalPipeline
import com.procam.ai.processing.EditAdjustments
import com.procam.ai.storage.GalleryItem
import com.procam.ai.storage.MediaStoreSaver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun GalleryEditorScreen(
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var items by remember { mutableStateOf<List<GalleryItem>>(emptyList()) }
    var selectedItem by remember { mutableStateOf<GalleryItem?>(null) }
    var originalBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var editedBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var adjustments by remember { mutableStateOf(EditAdjustments()) }
    var showingBefore by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        items = withContext(Dispatchers.IO) { MediaStoreSaver.loadRecentPhotos(context) }
    }

    LaunchedEffect(selectedItem) {
        val item = selectedItem ?: return@LaunchedEffect
        adjustments = EditAdjustments()
        val bmp = withContext(Dispatchers.IO) { MediaStoreSaver.decodeBitmapFromUri(context, item.uri, 1280) }
        originalBitmap = bmp
        editedBitmap = bmp
    }

    LaunchedEffect(adjustments, originalBitmap) {
        val orig = originalBitmap ?: return@LaunchedEffect
        editedBitmap = withContext(Dispatchers.Default) {
            ComputationalPipeline.applyEditorAdjustments(orig, adjustments)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0B0D12))
            .statusBarsPadding()
    ) {
        // TopBar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = {
                if (selectedItem != null) {
                    selectedItem = null
                    originalBitmap = null
                    editedBitmap = null
                } else {
                    onBack()
                }
            }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar", tint = Color.White)
            }

            Text(
                text = if (selectedItem == null) "Galeria ProCam" else "Editor Computacional",
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )

            if (selectedItem != null && editedBitmap != null) {
                IconButton(onClick = {
                    val bmpToSave = editedBitmap ?: return@IconButton
                    scope.launch {
                        val uri = withContext(Dispatchers.IO) {
                            MediaStoreSaver.saveBitmap(context, bmpToSave, prefix = "PROCAM_EDIT", quality = 98)
                        }
                        Toast.makeText(
                            context,
                            if (uri != null) "Cópia editada salva na galeria" else "Erro ao exportar",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }) {
                    Icon(Icons.Default.Save, contentDescription = "Exportar", tint = Color(0xFF60A5FA))
                }
            } else {
                Spacer(modifier = Modifier.padding(24.dp))
            }
        }

        if (selectedItem == null) {
            if (items.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Nenhuma foto encontrada.", color = Color.Gray)
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    modifier = Modifier.fillMaxSize().padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(items) { item ->
                        GalleryThumb(item = item, onClick = { selectedItem = item })
                    }
                }
            }
        } else {
            // Visualização com toque prolongado para Antes/Depois
            val displayBmp = if (showingBefore) originalBitmap else editedBitmap
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(Color.Black)
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onPress = {
                                showingBefore = true
                                tryAwaitRelease()
                                showingBefore = false
                            }
                        )
                    },
                contentAlignment = Alignment.Center
            ) {
                displayBmp?.let { bmp ->
                    Image(
                        bitmap = bmp.asImageBitmap(),
                        contentDescription = "Preview",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                Text(
                    text = if (showingBefore) "ANTES (ORIGINAL)" else "Segure a foto para comparar",
                    color = Color.White,
                    fontSize = 11.sp,
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(8.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0x99000000))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }

            // Sliders reais do editor OpenCV
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(280.dp)
                    .background(Color(0xFF111827))
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Aplicar HDR Computacional", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Switch(
                        checked = adjustments.applyHdrBoost,
                        onCheckedChange = { adjustments = adjustments.copy(applyHdrBoost = it) }
                    )
                }

                EditorSlider("Exposição", adjustments.exposure, -1f..1f) {
                    adjustments = adjustments.copy(exposure = it)
                }
                EditorSlider("Contraste", adjustments.contrast, 0.6f..1.5f) {
                    adjustments = adjustments.copy(contrast = it)
                }
                EditorSlider("Saturação", adjustments.saturation, 0f..1.8f) {
                    adjustments = adjustments.copy(saturation = it)
                }
                EditorSlider("Temperatura", adjustments.temperature, -1f..1f) {
                    adjustments = adjustments.copy(temperature = it)
                }
                EditorSlider("Sombras e Realces", adjustments.shadowsHighlights, 0f..1f) {
                    adjustments = adjustments.copy(shadowsHighlights = it)
                }
                EditorSlider("Nitidez", adjustments.sharpness, 0f..1f) {
                    adjustments = adjustments.copy(sharpness = it)
                }

                Spacer(modifier = Modifier.height(6.dp))
                Button(
                    onClick = { adjustments = EditAdjustments() },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Resetar Edições")
                }
            }
        }
    }
}

@Composable
private fun GalleryThumb(item: GalleryItem, onClick: () -> Unit) {
    val context = LocalContext.current
    var thumb by remember(item.uri) { mutableStateOf<Bitmap?>(null) }

    LaunchedEffect(item.uri) {
        thumb = withContext(Dispatchers.IO) {
            MediaStoreSaver.decodeBitmapFromUri(context, item.uri, 280)
        }
    }

    Box(
        modifier = Modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(4.dp))
            .background(Color(0xFF1F2937))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        thumb?.let {
            Image(
                bitmap = it.asImageBitmap(),
                contentDescription = item.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

@Composable
private fun EditorSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit
) {
    Text("$label: ${"%.2f".format(value)}", color = Color(0xFFD1D5DB), fontSize = 12.sp)
    Slider(
        value = value,
        onValueChange = onChange,
        valueRange = range,
        modifier = Modifier.height(30.dp)
    )
}
